"""
CLI de dtcoach. Un comando por paso del roadmap; ningún módulo importa cli.

    dtcoach aplanar          eventos .json.gz  -> data/interim/events/*.parquet
    dtcoach partidos         matches .json.gz  -> partidos + DT por partido
    dtcoach fase0            transiciones de TODA la liga con DT, rival y localía
    dtcoach cv-k             elige K fuera de muestra, por partido
    dtcoach mezcla --K k     ajusta la mezcla, responsabilidades, resumen y figuras
    dtcoach bondad --K k     KS de duración: K=1 contra la mezcla
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import polars as pl

from . import eras, ingest
from .config import Config
from .grid import StateSpace
from .possessions import build_transitions, coordinate_sanity


def _space(cfg: Config) -> StateSpace:
    p = cfg["pitch"]
    return StateSpace(nx=p["nx"], ny=p["ny"], length=p["length"], width=p["width"],
                      phases=tuple(cfg["phase_order"]))


def _json(obj, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str))


def _trans(cfg) -> pl.DataFrame:
    p = cfg.ruta("transiciones")
    if not p.exists():
        sys.exit(f"No existe {p}. Corre `dtcoach fase0` primero.")
    return pl.read_parquet(p)


# ----------------------------------------------------------------------
def cmd_aplanar(a, cfg):
    from .aplanar import aplanar
    rep = aplanar(cfg.ruta("raw_events"), cfg.ruta("eventos_parquet"),
                  por_lote=a.por_lote, hilos=a.hilos, forzar=a.forzar)
    _json(rep, cfg.ruta("reportes") / "aplanar.json")
    print(json.dumps({k: (v if not isinstance(v, list) else len(v)) for k, v in rep.items()}, indent=2))
    if rep["errores"]:
        print(f"\n{len(rep['errores'])} archivos con error (ver reports/aplanar.json). NO se ignoran:")
        for e in rep["errores"][:10]:
            print("  ", e)
        sys.exit(2)


def cmd_partidos(a, cfg):
    from .partidos import dt_por_partido, leer_partidos
    df = leer_partidos(cfg.ruta("raw_matches"))
    dtp = dt_por_partido(df)
    cfg.ruta("partidos").parent.mkdir(parents=True, exist_ok=True)
    df.write_parquet(cfg.ruta("partidos"))
    dtp.write_parquet(cfg.ruta("dt_partido"))
    sin_dt = dtp.filter(pl.col("coach_api").is_null()).height
    multi = dtp.filter(pl.col("n_managers") > 1).height
    print(f"partidos: {df.height} · temporadas: {df['season_id'].n_unique()} · "
          f"equipos: {dtp['team'].n_unique()}")
    print(f"filas equipo-partido sin DT en el API: {sin_dt} · con >1 DT: {multi}")
    print(df.group_by("season_id", "season_name").len().sort("season_id"))


def cmd_fase0(a, cfg):
    from .partidos import dt_por_partido, verificar_eras
    t0 = time.time()
    space = _space(cfg)
    lf = ingest.load(cfg.ruta("eventos_parquet"))
    print("construyendo transiciones de toda la liga...", flush=True)
    trans = build_transitions(lf, space, cfg)
    print(f"  {trans.height:,} transiciones en {time.time() - t0:.0f}s", flush=True)

    v2 = cfg.ruta("eras_dir").parent / (cfg.ruta("eras_dir").name + "_v2")
    if v2.exists():
        print(f"  [AVISO] existe {v2.name} pero el config usa {cfg.ruta('eras_dir').name}. "
              "Si ya lo corregiste, apunta rutas.eras_dir y rutas.exclusiones a la versión _v2.")
    partidos = pl.read_parquet(cfg.ruta("partidos"))
    dtp = dt_por_partido(partidos)
    md = partidos.select("match_id", "match_date")
    eras.check_dates_cover(trans, md)

    equipos = trans["team"].unique().drop_nulls().to_list()
    mc = eras.match_coach_table_multi(md, cfg.ruta("eras_dir"), equipos)

    # Interinatos absorbidos (bug de Cervantes/Jardine): el par (partido, club)
    # se queda SIN DT en las dos columnas. Las posesiones siguen en la liga.
    excl_p = cfg.ruta("exclusiones")
    n_excl = 0
    if excl_p.exists():
        pares = []
        for club in equipos:
            try:
                ids = eras.load_exclusions(excl_p, club)
            except KeyError as e:
                print(f"  [aviso] exclusiones ignoradas: {e}")
                break
            pares += [(i, club) for i in ids]
        if pares:
            ex = pl.DataFrame(pares, schema={"match_id": pl.Int64, "club": pl.Utf8}, orient="row")
            antes = mc.height
            mc = mc.join(ex, on=["match_id", "club"], how="anti")
            n_excl = antes - mc.height
    print(f"  pares (partido, club) excluidos por interinato: {n_excl}")

    trans = eras.attach_coach(trans, mc, club=None)
    trans = eras.attach_coach_faced(trans, mc)
    trans = trans.join(dtp.select("match_id", "team", "local", "rival"),
                       on=["match_id", "team"], how="left")

    verif = verificar_eras(mc, dtp)
    rep_dir = cfg.ruta("reportes")
    rep_dir.mkdir(parents=True, exist_ok=True)
    verif.write_csv(rep_dir / "verificacion_eras.csv")

    san = coordinate_sanity(trans, space)
    cob = (trans.filter(pl.col("coach").is_not_null())
           .group_by("team", "coach")
           .agg(pl.col("match_id").n_unique().alias("partidos"),
                pl.col("poss_uid").n_unique().alias("posesiones"))
           .sort("partidos", descending=True))
    cob.write_csv(rep_dir / "cobertura_eras.csv")
    frac_null = trans.select(pl.col("coach").is_null().mean()).item()
    # ADR-v2-14: cuantas posesiones de StatsBomb contienen mas de una secuencia,
    # y que absorciones ocurren a mitad de posesion.
    medio = trans.filter(pl.col("is_absorbing")).with_columns(
        pl.len().over("poss_uid").alias("_n_abs")
    ).filter(pl.col("_n_abs") > 1)
    abs_names = {space.absorbing_index(a): a for a in space.absorbing}
    rep_seg = {
        "posesiones_con_varias_secuencias": medio["poss_uid"].n_unique(),
        "absorciones_a_mitad_por_tipo": {
            abs_names[int(k)]: int(v) for k, v in
            trans.filter(pl.col("is_absorbing")).sort(["poss_uid", "event_index"])
            .with_columns(pl.int_range(pl.len()).over("poss_uid").alias("_i"),
                          pl.len().over("poss_uid").alias("_n"))
            .filter(pl.col("_i") < pl.col("_n") - 1)
            .group_by("to_state").len().iter_rows()
        },
    }
    rep = {
        "transiciones": trans.height,
        "posesiones": trans["poss_uid"].n_unique(),
        "secuencias": trans["seq_uid"].n_unique(),
        **rep_seg,
        "partidos": trans["match_id"].n_unique(),
        "equipos": len(equipos),
        "estados_transitorios": space.n_transient,
        "frac_filas_sin_dt": round(float(frac_null), 4),
        "discrepancias_eras_vs_api": verif.height,
        "coordinate_sanity": san,
        "segundos": round(time.time() - t0, 1),
    }
    _json(rep, rep_dir / "fase0.json")
    out = cfg.ruta("transiciones")
    out.parent.mkdir(parents=True, exist_ok=True)
    trans.write_parquet(out, compression="zstd")
    print(json.dumps(rep, indent=2, ensure_ascii=False))
    print("\nTop eras por partidos (reports/cobertura_eras.csv):")
    print(cob.head(15))
    if not san["ok"]:
        print("\n[ALERTA] coordinate_sanity falló: la tasa de gol no crece hacia x=120.")
    if verif.height:
        print(f"\n[REVISAR] {verif.height} filas equipo-partido donde la era verificada y el "
              "`managers` del API no coinciden -> reports/verificacion_eras.csv")


def _datos(cfg):
    from .mezcla import DatosPosesion
    return DatosPosesion.desde_transiciones(_trans(cfg), _space(cfg))


def cmd_cv_k(a, cfg):
    from .graficas import curva_cv
    from .mezcla import cv_k
    mc = cfg["mezcla"]
    d = _datos(cfg)
    print(f"{d.n:,} posesiones · {int(d.largo.sum()):,} transiciones", flush=True)
    k_grid = a.k or mc["k_grid"]
    res, det = cv_k(d, k_grid, mc["lam"], mc["a0"], mc["folds"], cfg["seed"],
                    mc["n_init_cv"], mc["max_iter"], mc["tol"],
                    a.frac if a.frac is not None else mc["frac_partidos_cv"])
    out = cfg.ruta("reportes") / "mezcla"
    out.mkdir(parents=True, exist_ok=True)
    res.write_csv(out / "cv_k.csv")
    det.write_csv(out / "cv_k_pliegues.csv")
    curva_cv(res, out / "cv_k.png")
    print(res)
    print("\nLa verosimilitud NO elige K sola (ADR-v2-10): mira la ganancia acumulada,"
          "\nel KS de `dtcoach bondad` y si los tipos son distintos y estables.")


def cmd_mezcla(a, cfg):
    from .graficas import mapa_tipos
    from .mezcla import ajustar, guardar_json, responsabilidades, resumen_tipos
    mc = cfg["mezcla"]
    d = _datos(cfg)
    t0 = time.time()
    m = ajustar(d, a.K, mc["lam"], mc["a0"], mc["n_init"], mc["max_iter"], mc["tol"],
                cfg["seed"], verbose=True, init=a.init, n_corto=mc.get("n_corto", 25))
    r = responsabilidades(m, d)
    dirm = cfg.ruta("mezcla_dir")
    dirm.mkdir(parents=True, exist_ok=True)
    m.guardar(dirm / f"mezcla_K{a.K}.npz")
    resp = d.meta.with_columns(
        *[pl.Series(f"r_{k + 1}", r[:, k]) for k in range(a.K)],
        pl.Series("tipo", r.argmax(axis=1) + 1),
        pl.Series("largo", d.largo),
    )
    resp.write_parquet(dirm / f"responsabilidades_K{a.K}.parquet")
    res = resumen_tipos(m, d, r, t_min=cfg["bondad"]["t_min"])
    rep = cfg.ruta("reportes") / "mezcla"
    guardar_json(res, rep / f"tipos_K{a.K}.json")
    guardar_json(m.diagnostico, rep / f"estabilidad_K{a.K}.json")
    mapa_tipos(res, d.nx, d.ny, rep / f"tipos_K{a.K}_visitas.png")
    mapa_tipos(res, d.nx, d.ny, rep / f"tipos_K{a.K}_inicio.png",
               clave="inicio_por_zona", etiqueta="inicio")
    print(f"\najustado en {time.time() - t0:.0f}s")
    print(f"{'tipo':>4} {'pi':>6} {'E[T] mod':>9} {'E[T] emp':>9} {'P(rem)':>7} "
          f"{'xG/pos mod':>11} {'xG/pos emp':>11}")
    for t in res:
        print(f"{t['tipo']:>4} {t['pi']:6.3f} {t['E_T_modelo']:9.2f} {t['E_T_empirico']:9.2f} "
              f"{t['P_gol'] + t['P_remate_sin_gol']:7.3f} {t['xG_por_posesion_modelo']:11.4f} "
              f"{t['xG_por_posesion_empirico']:11.4f}")
    dg = m.diagnostico
    if a.K > 1:
        if dg.get("init") == "escalera":
            print(f"\nAjustado por escalera (ADR-v2-17). Confirma con: dtcoach reproducibilidad --K {a.K}")
        else:
            print(f"\nEstabilidad (ADR-v2-15): el mejor óptimo lo alcanzan {dg['reproducibilidad']} de "
                  f"{len(dg['arranques'])} arranques (|ΔJ| ≤ {dg['tol_J']:.0f})")
        print(f"   {'ΔJ':>9} {'it':>5} {'acuerdo':>8} {'máx|Δπ|':>8} {'máx|ΔE[T]|rel':>14} {'máx|ΔP(rem)|':>13}")
        for f in sorted(dg["arranques"], key=lambda f: f["delta_J"]):
            print(f"   {f['delta_J']:9.1f} {f['iteraciones']:5d} {f['acuerdo']:8.3f} {f['max_dif_pi']:8.3f} "
                  f"{f['max_dif_ET_rel']:14.3f} {f['max_dif_Premate']:13.3f}")
    print("\nNOMBRA LOS TIPOS SOLO DESPUÉS DE MIRAR LAS FIGURAS (ADR-v2-06).")


def cmd_repro(a, cfg):
    from .mezcla import guardar_json, reproducibilidad
    mc = cfg["mezcla"]
    d = _datos(cfg)
    r = reproducibilidad(d, a.K, mc["lam"], mc["a0"], a.semillas, mc["max_iter"], mc["tol"],
                         mc.get("n_corto", 25))
    guardar_json(r, cfg.ruta("reportes") / "mezcla" / f"reproducibilidad_K{a.K}.json")
    print(f"K={a.K} · rango de J entre semillas = {r['rango_J']:.1f} · "
          f"acuerdo mínimo = {r['acuerdo_minimo']:.3f}")
    print(f"{'semilla':>8} {'ΔJ':>9} {'acuerdo':>8} {'máx|Δπ|':>8} {'máx|ΔE[T]|rel':>14}")
    for f in r["semillas"]:
        print(f"{f['semilla']:8d} {f['delta_J']:9.1f} {f['acuerdo']:8.3f} {f['max_dif_pi']:8.3f} "
              f"{f['max_dif_ET_rel']:14.3f}")
    print("\nCriterio (ADR-v2-17): rango de J < 50 y acuerdo mínimo >= 0.95.")


def cmd_curva_k(a, cfg):
    """Estabilidad y ajuste para muchos K: la figura que justifica la elección de K.

    Escribe una fila por K en cuanto termina (si se corta, lo corrido no se
    pierde y se reanuda saltando los K ya hechos).
    """
    import time as _t

    from .graficas import curva_estabilidad
    from .mezcla import ajustar, bondad_largo, loglik_por_posesion, pooled, reproducibilidad
    mc, bc = cfg["mezcla"], cfg["bondad"]
    out = cfg.ruta("reportes") / "mezcla"
    out.mkdir(parents=True, exist_ok=True)
    csv = out / "curva_k.csv"
    hechos = set(pl.read_csv(csv)["K"].to_list()) if csv.exists() else set()
    d = _datos(cfg)
    for K in a.k:
        if K in hechos:
            print(f"K={K}: ya estaba en {csv.name}, se salta")
            continue
        t0 = _t.time()
        r = reproducibilidad(d, K, mc["lam"], mc["a0"], a.semillas, mc["max_iter"], mc["tol"],
                             mc.get("n_corto", 25))
        Qp, mup = pooled(d)
        m = ajustar(d, K, mc["lam"], mc["a0"], max_iter=mc["max_iter"], tol=mc["tol"],
                    seed=a.semillas[0], Qp=Qp, mup=mup, init="escalera", n_corto=mc.get("n_corto", 25))
        b = bondad_largo(m, d, bc["t_min"], bc["kmax"])
        fila = pl.DataFrame([{
            "K": K, "rango_J": r["rango_J"], "acuerdo_minimo": r["acuerdo_minimo"],
            # J incluye el prior (crece con K): NO sirve entre K distintos.
            # Se compara la log-verosimilitud de los DATOS.
            "loglik_datos": float(loglik_por_posesion(m, d).sum()),
            "nats_por_transicion": float(loglik_por_posesion(m, d).sum()) / float(d.largo.sum()),
            "KS": b["KS"], "pi_minimo": float(m.pi.min()),
            "reproducible": bool(r["rango_J"] < 50 and r["acuerdo_minimo"] >= 0.95),
            "segundos": round(_t.time() - t0, 1),
        }])
        (pl.concat([pl.read_csv(csv), fila], how="diagonal_relaxed") if csv.exists() else fila).sort("K").write_csv(csv)
        print(f"K={K}: acuerdo={r['acuerdo_minimo']:.3f} rango_J={r['rango_J']:.1f} KS={b['KS']:.4f} "
              f"π_min={m.pi.min():.3f} ({_t.time() - t0:.0f}s)", flush=True)
    tabla = pl.read_csv(csv).sort("K")
    curva_estabilidad(tabla, out / "curva_k.png")
    with pl.Config(tbl_rows=60):
        print(tabla)


def _elo(cfg, forzar=False):
    from .elo import ajustar_elo
    ruta = cfg.ruta("elo")
    if ruta.exists() and not forzar:
        return pl.read_parquet(ruta)
    ec = cfg["elo"]
    r = ajustar_elo(pl.read_parquet(cfg.ruta("partidos")), ec["K_grid"], ec["h_grid"],
                    ec["inicial"], ec["burn_in"])
    ruta.parent.mkdir(parents=True, exist_ok=True)
    r.previo.write_parquet(ruta)
    rep = cfg.ruta("reportes") / "fase2"
    rep.mkdir(parents=True, exist_ok=True)
    _json({"K": r.K, "h": r.h, "logperdida": r.logperdida,
           "calibracion": r.calibracion.with_columns(pl.col("bin").cast(pl.Utf8)).to_dicts()},
          rep / "elo.json")
    print(f"Elo: K={r.K:g}, h={r.h:g}, log-pérdida={r.logperdida:.4f}")
    print(r.calibracion)
    if r.K in (min(ec["K_grid"]), max(ec["K_grid"])) or r.h in (min(ec["h_grid"]), max(ec["h_grid"])):
        print("[AVISO] el óptimo cae en el borde de la rejilla: amplíala en config.elo")
    return r.previo


def cmd_elo(a, cfg):
    _elo(cfg, forzar=True)


def cmd_fase2(a, cfg):
    from .contexto import tabla_secuencias
    from .graficas import efectos_contexto, eficiencia, perfil_familias
    from .hipotesis import correr, tabla_md
    from .mezcla import Mezcla
    c2 = dict(cfg["fase2"])
    foco = a.foco or cfg["foco"]["coach"]
    c2["foco"] = foco
    K = c2["K"]
    fams = c2["familias"]
    elo = _elo(cfg)
    m = Mezcla.cargar(cfg.ruta("mezcla_dir") / f"mezcla_K{K}.npz")
    t = tabla_secuencias(_trans(cfg), _space(cfg), m, pl.read_parquet(cfg.ruta("partidos")), elo, cfg, foco)
    print(f"{t.height:,} secuencias · foco «{foco}»: {int(t['f'].sum()):,} de ataque, "
          f"{int(t['g'].sum()):,} de defensa, {t.filter(pl.col('f'))['match_id'].n_unique()} partidos", flush=True)
    res = correr(t, fams, c2, cfg["seed"])
    rep = cfg.ruta("reportes") / "fase2"
    rep.mkdir(parents=True, exist_ok=True)
    slug = foco.lower().replace(" ", "_")
    _json({k: v for k, v in res.items()}, rep / f"hipotesis_{slug}.json")
    perfil_familias(res, fams, foco, rep / f"familias_{slug}.png")
    efectos_contexto(res, fams, foco, rep / f"contexto_{slug}.png")
    eficiencia(res, fams, foco, rep / f"eficiencia_{slug}.png")
    md = [f"# Resultados de la fase 2 — {foco}", "",
          f"Secuencias del foco: {int(t['f'].sum()):,} (ataque), {int(t['g'].sum()):,} (defensa). "
          f"Partidos: {res['perfiles']['n_partidos_foco']} del foco, {res['perfiles']['n_partidos_liga']} de la liga.",
          f"Modelo convergió: {res['modelo']['convergio']}. "
          f"Columnas no estimables: {res['modelo']['columnas_no_estimables'] or 'ninguna'}. "
          + (f"⚠ {res['modelo']['aviso']}" if 'aviso' in res['modelo'] else ""),
          "", tabla_md(res), "", "## En la cancha", ""]
    md += [f"- {f}" for f in res["frases"]]
    (rep / f"RESULTADOS_{slug}.md").write_text("\n".join(md), encoding="utf-8")
    print(f"columnas no estimables: {res['modelo']['columnas_no_estimables'] or 'ninguna'}")
    if "aviso" in res["modelo"]:
        print("⚠", res["modelo"]["aviso"])
    print(tabla_md(res))
    print()
    for f in res["frases"]:
        print("·", f)
    print(f"\nReporte: {rep / f'RESULTADOS_{slug}.md'}")


def _tabla_fase2(cfg, foco):
    from .contexto import tabla_secuencias
    from .mezcla import Mezcla
    K = cfg["fase2"]["K"]
    m = Mezcla.cargar(cfg.ruta("mezcla_dir") / f"mezcla_K{K}.npz")
    return tabla_secuencias(_trans(cfg), _space(cfg), m, pl.read_parquet(cfg.ruta("partidos")),
                            _elo(cfg), cfg, foco)


def cmd_fase3(a, cfg):
    from .fase3 import por_club
    from .graficas import comparar_clubes
    c2 = dict(cfg["fase2"])
    foco = a.foco or cfg["foco"]["coach"]
    t = _tabla_fase2(cfg, foco)
    clubes = (t.filter(pl.col("f")).group_by("team").agg(pl.col("match_id").n_unique().alias("p"))
               .filter(pl.col("p") >= a.min_partidos).sort("p", descending=True)["team"].to_list())
    print(f"{foco}: clubes con ≥ {a.min_partidos} partidos: {clubes}", flush=True)
    res = por_club(t, foco, clubes, c2["familias"], c2, cfg["seed"])
    rep = cfg.ruta("reportes") / "fase3"
    rep.mkdir(parents=True, exist_ok=True)
    slug = foco.lower().replace(" ", "_")
    _json(res, rep / f"por_club_{slug}.json")
    comparar_clubes(res, c2["familias"], foco, rep / f"por_club_{slug}.png")
    from .hipotesis import tabla_md
    md = [f"# ¿Es él o el plantel? — {foco}", ""]
    for club, r in res["clubes"].items():
        md += [f"## {club} ({r['partidos']} partidos)", ""]
        if "aviso_foco" in r["modelo"]:
            md += [f"⚠ {r['modelo']['aviso_foco']}", ""]
        md += [tabla_md(r), ""]
    for par, v in res.get("veredicto", {}).items():
        md += [f"## Veredicto {par} (H9–H12, pre-registradas)", ""]
        if "_aviso" in v:
            md += [f"⚠ {v['_aviso']}", ""]
        for h, x_ in v.items():
            if h.startswith("_"):
                continue
            md.append(f"**{h}**")
            for fam, x in x_.items():
                if isinstance(x, dict):
                    md.append(f"- {fam}: dif {100 * x['dif']:+.1f} pp, IC [{100 * x['lo']:+.1f}, {100 * x['hi']:+.1f}]"
                              f" → {'distinta' if x['excluye_0'] else 'no detectamos diferencia'}")
                else:
                    md.append(f"- {fam}: {'VIAJA (ambos clubes, mismo signo)' if x else 'no se detecta en ambos'}")
            md.append("")
    (rep / f"POR_CLUB_{slug}.md").write_text("\n".join(md), encoding="utf-8")
    print("\n".join(md))


def cmd_atlas(a, cfg):
    """El atlas NO depende del foco (ajusta todas las eras); el foco solo se resalta.
    Se reutiliza reports/fase3/atlas.csv si existe (usa --rehacer para recalcular)."""
    from .fase3 import atlas
    from .graficas import mapa_atlas
    c2 = dict(cfg["fase2"])
    foco = a.foco or cfg["foco"]["coach"]
    rep = cfg.ruta("reportes") / "fase3"
    rep.mkdir(parents=True, exist_ok=True)
    csv = rep / "atlas.csv"
    if csv.exists() and not a.rehacer:
        tab = pl.read_csv(csv)
        print(f"atlas reutilizado de {csv.name} ({tab.height} eras); --rehacer para recalcular")
    else:
        t = _tabla_fase2(cfg, cfg["foco"]["coach"])
        tab = atlas(t, c2["familias"], c2, cfg["seed"], a.min_partidos)
        tab.write_csv(csv)
    slug = foco.lower().replace(" ", "_")
    mapa_atlas(tab, foco, c2["familias"], rep / f"atlas_{slug}.png")
    with pl.Config(tbl_rows=80, tbl_cols=8, fmt_str_lengths=24):
        print(tab.select("coach", "team", "partidos", "norma_ataque_pp", "norma_defensa_pp", "p_H1", "p_H2"))
    for col, nombre in (("norma_ataque_pp", "ofensiva"), ("norma_defensa_pp", "defensiva")):
        orden = tab.sort(col, descending=True).with_row_index("rango")
        for r in orden.filter(pl.col("coach") == foco).iter_rows(named=True):
            print(f"{foco} ({r['team']}): puesto {r['rango'] + 1} de {tab.height} en separación {nombre} "
                  f"({r[col]:.1f} pp); mediana de la liga: {tab[col].median():.1f} pp")
    if tab.filter(pl.col("coach") == foco).height == 0:
        print(f"{foco} no tiene eras con ≥ {a.min_partidos} partidos en el atlas.")


def _equipo_partido(cfg) -> pl.DataFrame:
    """Una fila por equipo-partido: DT, localía, Elo, temporada y fecha."""
    tr = pl.read_parquet(cfg.ruta("transiciones"), columns=["match_id", "team", "coach", "local"])
    tp = tr.group_by("match_id", "team").agg(pl.col("coach").drop_nulls().first(), pl.col("local").first())
    elo = _elo(cfg).with_columns(((pl.col("elo") - pl.col("elo_rival")) / 100).alias("elo_dif"))
    part = pl.read_parquet(cfg.ruta("partidos")).select("match_id", "season_id", "match_date")
    return (tp.join(elo.select("match_id", "team", "elo_dif"), on=["match_id", "team"], how="left")
              .join(part, on="match_id", how="left")
              .with_columns(pl.col("local").fill_null(False), pl.col("elo_dif").fill_null(0.0)))


def cmd_decisiones(a, cfg):
    from .decisiones import correr_decisiones, leer_eventos
    from .graficas import figura_decisiones
    c2 = dict(cfg["fase2"])
    foco = a.foco or cfg["foco"]["coach"]
    print("leyendo cambios, reacomodos y onces...", flush=True)
    ev = leer_eventos(ingest.scan_events(cfg.ruta("eventos_parquet")))
    res = correr_decisiones(ev, _equipo_partido(cfg), foco, c2, cfg["seed"])
    rep = cfg.ruta("reportes") / "fase3"
    rep.mkdir(parents=True, exist_ok=True)
    slug = foco.lower().replace(" ", "_")
    _json({k: v for k, v in res.items() if not k.startswith("_")}, rep / f"decisiones_{slug}.json")
    figura_decisiones(res, foco, rep / f"decisiones_{slug}.png")
    H = res["hipotesis"]
    L = [f"# Decisiones desde la banca — {foco}", "",
         f"Equipo-minuto: {res['n']['equipo_minuto']:,} · sustituciones: {res['n']['sustituciones']:,} "
         f"({res['n']['sustituciones_foco']} de {foco}) · equipo-partido: {res['n']['equipo_partido']:,}", "",
         "| id | qué se prueba | resultado | p | q (BH) | evidencia |", "|---|---|---|---|---|---|"]
    for k, h in H.items():
        est = f"W={h['W']:.1f} (gl {h['gl']})" if "W" in h else \
              f"{h['foco']:.3f} vs {h['liga']:.3f} (dif {h['dif']:+.3f} [{h['lo']:+.3f}, {h['hi']:+.3f}])"
        L.append(f"| {k} | {h['nombre']} | {est} | {h['p']:.4f} | {h['q']:.4f} | {h['etiqueta']} |")
    L += ["", "## En la cancha", ""]
    for marc, v in res["primer_cambio"].items():
        L.append(f"- **Primer cambio del 2º tiempo, {marc}:** minuto {v['minuto_foco']:.1f} contra "
                 f"{v['minuto_liga']:.1f} de la liga ({v['dif']:+.1f} min, IC [{v['lo']:+.1f}, {v['hi']:+.1f}]).")
    tipos = ["defensivo", "mismo puesto", "ofensivo"]
    for marc, v in res["tipo_cambio"].items():
        L.append(f"- **Tipo de cambio, {marc}:** " + "; ".join(
            f"{t} {100 * v['P_foco'][i]:.0f} % (liga {100 * v['P_liga'][i]:.0f} %, "
            f"dif {100 * v['dif'][i]:+.1f} pp [{100 * v['lo'][i]:+.1f}, {100 * v['hi'][i]:+.1f}])"
            for i, t in enumerate(tipos)))
    por_club: dict = {}
    for r in res["formaciones_foco"]:
        por_club.setdefault(r["team"], []).append(r)
    for club, fs in por_club.items():
        tot = sum(r["len"] for r in fs)
        L.append(f"- **Formaciones iniciales en {club}** ({tot} partidos, {len(fs)} sistemas): " + ", ".join(
            f"{r['tactics_formation']} ({r['len']}, {100 * r['len'] / tot:.0f} %)" for r in fs[:5]))
    (rep / f"DECISIONES_{slug}.md").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L))


def cmd_simulador(a, cfg):
    from .graficas import figura_escenarios, figura_xpts
    from .hipotesis import modelo_contexto
    from .perfil import perfiles
    from .simulador import calibracion_contexto, escenarios, resumen_xpts, xpts_por_equipo_partido
    c2 = dict(cfg["fase2"])
    foco = a.foco or cfg["foco"]["coach"]
    fams = c2["familias"]
    K = len(fams)
    rep = cfg.ruta("reportes") / "fase3"
    rep.mkdir(parents=True, exist_ok=True)
    slug = foco.lower().replace(" ", "_")
    tp = _equipo_partido(cfg)
    print("puntos esperados (Poisson-binomial exacta)...", flush=True)
    x = xpts_por_equipo_partido(ingest.scan_events(cfg.ruta("eventos_parquet")), tp)
    x = x.join(tp.select("match_id", "team", "match_date"), on=["match_id", "team"], how="left")
    rx = resumen_xpts(x, foco)
    figura_xpts(x.filter(pl.col("coach") == foco), foco, rep / f"xpts_{slug}.png")
    print("escenarios y calibración del modelo de contexto...", flush=True)
    t = _tabla_fase2(cfg, foco)
    m, D, _ = modelo_contexto(t, K, c2.get("ref", 1))
    pf = perfiles(t, K, n_boot=c2["n_boot"], seed=cfg["seed"])
    xg_f, xg_l = pf["ataque"]["foco"][K:2 * K], pf["ataque"]["liga"][K:2 * K]
    se_f = [(h - l) / 3.92 for l, h in zip(pf["ataque"]["lo"][K:2 * K], pf["ataque"]["hi"][K:2 * K])]
    esc = escenarios(t, m, D, xg_f, xg_l, fams, m.simular(200, cfg["seed"]), se_f, cfg["seed"])
    esc.write_csv(rep / f"escenarios_{slug}.csv")
    figura_escenarios(esc, foco, rep / f"escenarios_{slug}.png")
    cal = calibracion_contexto(t, m, D, K)
    cal.write_csv(rep / f"calibracion_contexto_{slug}.csv")
    _json({"xpts": rx, "calibracion_error_tv_medio": float(cal["error_tv"].mean()) if cal.height else None,
           "calibracion_ruido_tv_medio": float(cal["ruido_tv"].mean()) if cal.height else None},
          rep / f"simulador_{slug}.json")
    v, f_ = rx["validacion"], rx["foco"]
    L = [f"# Simulador — {foco} (exploratorio)", "",
         "## Puntos contra puntos esperados", "",
         f"Validación en toda la liga: {v['puntos_totales']:,} puntos reales contra {v['xPts_totales']:,.0f} "
         f"esperados (error relativo {100 * v['error_relativo']:.2f} %).", "",
         f"{foco}: {f_['puntos']} puntos en {f_['partidos']} partidos contra {f_['xPts']:.1f} esperados "
         f"({f_['dif']:+.1f} puntos, z = {f_['z']:+.2f}, p = {f_['p']:.3f}). "
         f"Por partido: {f_['puntos_por_partido']:.2f} reales contra {f_['xPts_por_partido']:.2f} esperados.", "",
         "## Calibración del modelo de contexto (celdas con ≥ 300 secuencias del foco)", "",
         (f"Error medio (distancia de variación total, predicha contra observada): "
          f"{100 * float(cal['error_tv'].mean()):.2f} pp en {cal.height} celdas; el ruido de muestreo esperado "
          f"con esos tamaños de celda es {100 * float(cal['ruido_tv'].mean()):.2f} pp "
          f"(cociente {float(cal['error_tv'].mean() / cal['ruido_tv'].mean()):.2f}: cerca de 1 = el error es ruido)."
          if cal.height else "Sin celdas suficientes."),
         "", "## Escenarios (xG por secuencia, foco contra liga en el mismo escenario)", ""]
    for r in esc.sort("dif_xG_sec").iter_rows(named=True):
        L.append(f"- {r['marcador']}, min {r['minuto']}, {'local' if r['local'] else 'visitante'}, {r['rival']}: "
                 f"{r['xG_sec_foco']:.4f} contra {r['xG_sec_liga']:.4f} ({r['dif_xG_sec']:+.4f} "
                 f"[{r['lo']:+.4f}, {r['hi']:+.4f}])")
    (rep / f"SIMULADOR_{slug}.md").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L[:12]))
    print(f"... escenarios completos en {rep / f'SIMULADOR_{slug}.md'}")


def cmd_bondad(a, cfg):
    from .mezcla import Mezcla, ajustar, bondad_largo, guardar_json
    mc, bc = cfg["mezcla"], cfg["bondad"]
    d = _datos(cfg)
    salida = []
    for K in a.K:
        p = cfg.ruta("mezcla_dir") / f"mezcla_K{K}.npz"
        m = Mezcla.cargar(p) if p.exists() else ajustar(
            d, K, mc["lam"], mc["a0"], mc["n_init"], mc["max_iter"], mc["tol"], cfg["seed"])
        b = bondad_largo(m, d, bc["t_min"], bc["kmax"], a.n_boot, cfg["seed"])
        salida.append(b)
        extra = f" · p_conservador={b['p_conservador']:.4f}" if "p_conservador" in b else ""
        print(f"K={K}: KS={b['KS']:.5f} · E[T] modelo={b['E_T_modelo']:.3f} "
              f"vs empírico={b['E_T_empirico']:.3f}{extra}")
    guardar_json(salida, cfg.ruta("reportes") / "mezcla" / "bondad_largo.json")
    print("\nSupervivencia P(T > t) empírica vs modelo (primeros t):")
    print(f"{'t':>3} {'empírica':>9} " + " ".join(f"{'K=' + str(b['K']):>9}" for b in salida))
    for i in range(min(20, len(salida[0]["supervivencia"]))):
        fila = salida[0]["supervivencia"][i]
        print(f"{fila['t']:>3} {fila['empirica']:9.4f} " +
              " ".join(f"{b['supervivencia'][i]['modelo']:9.4f}" for b in salida))


# ----------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(prog="dtcoach", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=None)
    sp = ap.add_subparsers(dest="cmd", required=True)

    s = sp.add_parser("aplanar")
    s.add_argument("--por-lote", type=int, default=40)
    s.add_argument("--hilos", type=int, default=6)
    s.add_argument("--forzar", action="store_true")
    s.set_defaults(f=cmd_aplanar)

    sp.add_parser("partidos").set_defaults(f=cmd_partidos)
    sp.add_parser("fase0").set_defaults(f=cmd_fase0)

    s = sp.add_parser("cv-k")
    s.add_argument("--k", type=int, nargs="*", help="rejilla de K (default: config)")
    s.add_argument("--frac", type=float, default=None, help="fracción de partidos para la CV")
    s.set_defaults(f=cmd_cv_k)

    s = sp.add_parser("mezcla")
    s.add_argument("--K", type=int, required=True)
    s.add_argument("--init", default="escalera", choices=["escalera", "kmeans"])
    s.set_defaults(f=cmd_mezcla)

    s = sp.add_parser("reproducibilidad")
    s.add_argument("--K", type=int, required=True)
    s.add_argument("--semillas", type=int, nargs="+", default=[1, 2, 3])
    s.set_defaults(f=cmd_repro)

    sp.add_parser("elo").set_defaults(f=cmd_elo)

    s = sp.add_parser("fase2")
    s.add_argument("--foco", default=None, help="DT focal (default: config.foco.coach)")
    s.set_defaults(f=cmd_fase2)

    s = sp.add_parser("fase3")
    s.add_argument("--foco", default=None)
    s.add_argument("--min-partidos", type=int, default=30)
    s.set_defaults(f=cmd_fase3)

    s = sp.add_parser("atlas")
    s.add_argument("--min-partidos", type=int, default=50)
    s.add_argument("--foco", default=None, help="técnico a resaltar (default: config.foco.coach)")
    s.add_argument("--rehacer", action="store_true")
    s.set_defaults(f=cmd_atlas)

    s = sp.add_parser("decisiones")
    s.add_argument("--foco", default=None)
    s.set_defaults(f=cmd_decisiones)

    s = sp.add_parser("simulador")
    s.add_argument("--foco", default=None)
    s.set_defaults(f=cmd_simulador)

    s = sp.add_parser("curva-k")
    s.add_argument("--k", type=int, nargs="+", default=list(range(2, 11)))
    s.add_argument("--semillas", type=int, nargs="+", default=[1, 2, 3])
    s.set_defaults(f=cmd_curva_k)

    s = sp.add_parser("bondad")
    s.add_argument("--K", type=int, nargs="+", required=True, help="p.ej. --K 1 6")
    s.add_argument("--n-boot", type=int, default=0)
    s.set_defaults(f=cmd_bondad)

    a = ap.parse_args(argv)
    cfg = Config.load(a.config)
    a.f(a, cfg)


if __name__ == "__main__":
    main()
