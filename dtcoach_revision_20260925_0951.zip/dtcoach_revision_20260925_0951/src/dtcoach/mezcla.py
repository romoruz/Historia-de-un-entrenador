"""
Capa 1 -- Mezcla de cadenas de Markov: el VOCABULARIO de posesiones de la liga.

MODELO
------
Cada posesion s tiene un tipo oculto Z_s en {1..K}. Dado el tipo, la posesion
es una trayectoria de una cadena absorbente propia:

    Pr(s) = sum_k pi_k * mu^k[z_1] * prod_t P^k[z_t, z_{t+1}]

pi_k   : proporcion de posesiones de tipo k (NO es una estacionaria; ADR-v2-07)
mu^k   : distribucion de inicio del tipo k
P^k    : matriz de transicion del tipo k (filas transitorias -> todos los estados)

K = 1 recupera exactamente la cadena del proyecto viejo (tests/test_mezcla.py).

ESTIMACION: EM con encogimiento (EM-MAP)
----------------------------------------
E: r_sk ∝ pi_k L_k(s)                       (en log-espacio)
M: P^k = (C^k + lam Q) / (n^k + lam),   C^k = sum_s r_sk C(s)
   mu^k = (M^k + a0 mu_pool) / (sum M^k + a0)
   pi_k = mean_s r_sk
El M-step es la moda posterior con prior Dirichlet(lam Q + 1): el mismo
estimador de encogimiento del proyecto viejo, ahora ponderado por r_sk. Con
esa lectura el EM es MONOTONO en el objetivo
    J = sum_s log Pr(s) + lam sum_k <Q, log P^k> + a0 sum_k <mu_pool, log mu^k>
(se comprueba en los tests).

TRUCO NUMERICO: cada posesion se guarda como un vector de conteos de celdas
(i, j) en una matriz dispersa S (n_pos x n_celdas). Entonces
    log L_k(s) = S[s] . log P^k        -> un producto disperso S @ logP
    C^k        = S^T r_k               -> otro producto disperso
Cada iteracion es O(nnz(S) * K), no un bucle por posesion.

K SE ELIGE FUERA DE MUESTRA, POR PARTIDO (ADR-v2-06)
----------------------------------------------------
El LRT de K contra K+1 no tiene nula chi^2 (frontera + no identificabilidad).
Se usa log-verosimilitud en partidos no vistos, regla de un error estandar,
y como criterio sustantivo el KS de duracion (`bondad_largo`).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import polars as pl
import scipy.sparse as sp
from scipy.cluster.vq import kmeans2
from scipy.optimize import linear_sum_assignment
from scipy.special import logsumexp

from .absorbing import Cadena, recompensa_xg
from .estimate import match_folds, shrink
from .grid import StateSpace

_EPS = 1e-300

META_COLS = (
    "seq_uid", "seq_n", "poss_uid", "match_id", "team", "coach", "coach_faced", "match_date",
    "play_pattern", "phase", "score_state", "period", "minute", "local", "rival",
)


# ======================================================================
# Datos
# ======================================================================
@dataclass
class DatosPosesion:
    S: sp.csr_matrix          # (n_pos, n_transient*n_states) conteos de celdas
    X: sp.csr_matrix          # (n_pos, n_transient) xG de remates por estado de origen
    inicio: np.ndarray        # (n_pos,) estado transitorio inicial
    largo: np.ndarray         # (n_pos,) transiciones hasta absorcion
    meta: pl.DataFrame        # una fila por posesion, MISMO orden que S
    n_transient: int
    n_states: int
    nx: int
    ny: int
    n_phases: int

    @property
    def n(self) -> int:
        return self.S.shape[0]

    @classmethod
    def desde_transiciones(cls, trans: pl.DataFrame, space: StateSpace) -> "DatosPosesion":
        """Una fila por SECUENCIA (`seq_uid`, ADR-v2-14) si existe; si no, por posesion."""
        uid = "seq_uid" if "seq_uid" in trans.columns else "poss_uid"
        df = trans.sort([uid, "event_index"]).with_columns(
            (pl.col(uid) != pl.col(uid).shift(1)).fill_null(True).alias("_nuevo")
        )
        nuevo = df["_nuevo"].to_numpy()
        pid = np.cumsum(nuevo) - 1
        starts = np.flatnonzero(nuevo)
        n = len(starts)
        nt, ns = space.n_transient, space.n_states
        fr = df["from_state"].to_numpy().astype(np.int64)
        to = df["to_state"].to_numpy().astype(np.int64)
        if fr.max(initial=0) >= nt or to.max(initial=0) >= ns:
            raise ValueError("Estados fuera del espacio: ¿cambió la malla o las fases sin rehacer fase0?")
        S = sp.csr_matrix((np.ones(len(fr)), (pid, fr * ns + to)), shape=(n, nt * ns))
        S.sum_duplicates()
        xg = df["xg"].fill_null(0.0).to_numpy() if "xg" in df.columns else np.zeros(len(fr))
        X = sp.csr_matrix((xg, (pid, fr)), shape=(n, nt))
        X.sum_duplicates()
        largo = np.diff(np.append(starts, len(fr)))
        cols = [c for c in META_COLS if c in df.columns]
        meta = df[starts].select(cols)
        return cls(S, X, fr[starts], largo, meta, nt, ns, space.nx, space.ny, len(space.phases))

    def sub(self, mask: np.ndarray) -> "DatosPosesion":
        idx = np.flatnonzero(mask) if mask.dtype == bool else np.asarray(mask)
        return DatosPosesion(
            self.S[idx], self.X[idx], self.inicio[idx], self.largo[idx],
            self.meta[idx], self.n_transient, self.n_states, self.nx, self.ny, self.n_phases,
        )

    # --- geometria de estados (para rasgos y graficas) -----------------
    def columna_x(self, estados: np.ndarray) -> np.ndarray:
        """Indice de franja en x (0 = propia porteria) de un estado transitorio."""
        zona = np.asarray(estados) // self.n_phases
        return zona // self.ny


# ======================================================================
# Modelo
# ======================================================================
@dataclass
class Mezcla:
    pi: np.ndarray            # (K,)
    mu: np.ndarray            # (K, n_transient)
    P: np.ndarray             # (K, n_transient, n_states)
    lam: float
    a0: float
    objetivo: list[float] = field(default_factory=list)
    diagnostico: dict = field(default_factory=dict)

    @property
    def K(self) -> int:
        return len(self.pi)

    def cadena(self, k: int) -> Cadena:
        return Cadena(self.P[k], self.mu.shape[1])

    def guardar(self, path: Path) -> None:
        np.savez_compressed(path, pi=self.pi, mu=self.mu, P=self.P, lam=self.lam,
                            a0=self.a0, objetivo=np.asarray(self.objetivo))

    @classmethod
    def cargar(cls, path: Path) -> "Mezcla":
        z = np.load(path)
        return cls(z["pi"], z["mu"], z["P"], float(z["lam"]), float(z["a0"]),
                   list(z["objetivo"]))


def pooled(d: DatosPosesion, lam0: float = 1.0) -> tuple[np.ndarray, np.ndarray]:
    """Cadena agregada de los datos dados, encogida levemente hacia la uniforme.

    Es el destino del encogimiento de cada P^k. lam0 > 0 garantiza entradas
    estrictamente positivas: una transicion que la liga nunca hizo en
    entrenamiento puede aparecer en prueba, y log 0 = -inf.
    """
    nt, ns = d.n_transient, d.n_states
    C = np.asarray(d.S.sum(axis=0)).ravel().reshape(nt, ns)
    Q = shrink(C, np.full((nt, ns), 1.0 / ns), lam0)
    m = np.bincount(d.inicio, minlength=nt).astype(float) + lam0 / nt
    return Q, m / m.sum()


def _loglik_tipos(d: DatosPosesion, P: np.ndarray, mu: np.ndarray) -> np.ndarray:
    """(n_pos, K) con log L_k(s) = log mu^k[z_1] + S[s] . log P^k."""
    K = P.shape[0]
    logP = np.log(np.maximum(P.reshape(K, -1), _EPS)).T      # (n_celdas, K)
    L = np.asarray(d.S @ logP)
    L += np.log(np.maximum(mu[:, d.inicio], _EPS)).T
    return L


def _m_step(d, r, Qp, mup, lam, a0):
    K = r.shape[1]
    nt, ns = d.n_transient, d.n_states
    C = np.asarray(d.S.T @ r).T.reshape(K, nt, ns)
    n = C.sum(axis=2, keepdims=True)
    P = (C + lam * Qp[None]) / (n + lam)
    M = np.stack([np.bincount(d.inicio, weights=r[:, k], minlength=nt) for k in range(K)])
    mu = (M + a0 * mup[None]) / (M.sum(axis=1, keepdims=True) + a0)
    pi = np.clip(r.mean(axis=0), 1e-12, None)
    return pi / pi.sum(), mu, P


def _objetivo(Lpi, P, mu, Qp, mup, lam, a0) -> float:
    datos = float(logsumexp(Lpi, axis=1).sum())
    prior_P = lam * float((Qp[None] * np.log(np.maximum(P, _EPS))).sum())
    prior_mu = a0 * float((mup[None] * np.log(np.maximum(mu, _EPS))).sum())
    return datos + prior_P + prior_mu


def rasgos(d: DatosPosesion) -> np.ndarray:
    """Rasgos baratos SOLO para inicializar el EM (no entran al modelo)."""
    nt, ns = d.n_transient, d.n_states
    celdas = np.arange(nt * ns)
    col_from = d.columna_x(celdas // ns).astype(float)
    to = celdas % ns
    remate = ((to == nt) | (to == nt + 1)).astype(float)   # GOAL, SHOT_NOGOAL
    media_x = np.asarray(d.S @ col_from).ravel() / np.maximum(d.largo, 1)
    datos_x = col_from[d.S.indices]
    max_x = np.maximum.reduceat(datos_x, d.S.indptr[:-1]) if d.S.nnz else np.zeros(d.n)
    remata = np.asarray(d.S @ remate).ravel()
    F = np.column_stack([np.log(d.largo), d.columna_x(d.inicio), media_x, max_x, remata])
    return (F - F.mean(0)) / np.maximum(F.std(0), 1e-9)


def _em(d, pi, mu, P, Qp, mup, lam, a0, max_iter, tol):
    """Bucle EM-MAP desde parametros dados. Devuelve (Mezcla, convergio)."""
    obj, convergio = [], len(pi) == 1
    for it in range(max_iter):
        Lpi = _loglik_tipos(d, P, mu) + np.log(pi)[None]
        obj.append(_objetivo(Lpi, P, mu, Qp, mup, lam, a0))
        r = np.exp(Lpi - logsumexp(Lpi, axis=1, keepdims=True))
        pi, mu, P = _m_step(d, r, Qp, mup, lam, a0)
        if len(pi) == 1 or (it > 0 and abs(obj[-1] - obj[-2]) < tol * abs(obj[-2])):
            convergio = True
            break
    Lpi = _loglik_tipos(d, P, mu) + np.log(pi)[None]
    obj.append(_objetivo(Lpi, P, mu, Qp, mup, lam, a0))
    return Mezcla(pi, mu, P, lam, a0, obj), convergio


def _desde_kmeans(d, K, F, rng, Qp, mup, lam, a0):
    if K == 1:
        r = np.ones((d.n, 1))
    else:
        _, lab = kmeans2(F, K, minit="++", seed=rng, iter=20)
        r = np.full((d.n, K), 0.1 / K)
        r[np.arange(d.n), lab] += 0.9
    return _m_step(d, r, Qp, mup, lam, a0)


def _partir(m: "Mezcla", k: int, rng, eps: float = 0.25):
    """Duplica el tipo k perturbando su distribucion de inicio en direcciones opuestas."""
    u = rng.normal(size=m.mu.shape[1])
    a = np.clip(m.mu[k] * np.exp(eps * u), 1e-12, None)
    b = np.clip(m.mu[k] * np.exp(-eps * u), 1e-12, None)
    mu = np.vstack([np.delete(m.mu, k, 0), a / a.sum(), b / b.sum()])
    P = np.concatenate([np.delete(m.P, k, 0), m.P[k][None], m.P[k][None]])
    pi = np.append(np.delete(m.pi, k), [m.pi[k] / 2, m.pi[k] / 2])
    return pi / pi.sum(), mu, P


def ajustar(
    d: DatosPosesion, K: int, lam: float, a0: float = 1.0, n_init: int = 3,
    max_iter: int = 300, tol: float = 1e-6, seed: int = 0,
    Qp: np.ndarray | None = None, mup: np.ndarray | None = None, verbose: bool = False,
    init: str = "escalera", n_corto: int = 25,
) -> Mezcla:
    """Ajusta la mezcla de K cadenas.

    init="escalera" (ADR-v2-17): sube de K-1 a K PARTIENDO un tipo. En cada
    nivel prueba partir cada uno de los K-1 tipos, corre `n_corto` iteraciones
    de EM para cada candidato y sigue con el mejor. Es determinista dada la
    semilla y encuentra el mismo optimo desde semillas distintas, cosa que
    k-means no lograba: con 461 mil secuencias, 10 arranques de k-means dieron
    9 optimos locales distintos y el mejor apareció UNA vez.
    init="kmeans": el metodo anterior, con `n_init` arranques. Se conserva como
    contraste independiente del optimo.
    """
    if lam <= 0:
        raise ValueError("lam debe ser > 0 (sin encogimiento, un tipo vacio da filas 0/0)")
    if Qp is None or mup is None:
        Qp, mup = pooled(d)
    todos: list[tuple[Mezcla, bool]] = []

    if init == "escalera":
        rng = np.random.default_rng([seed, K])
        pi, mu, P = _desde_kmeans(d, 1, None, rng, Qp, mup, lam, a0)
        m, conv = _em(d, pi, mu, P, Qp, mup, lam, a0, max_iter, tol)
        for nivel in range(2, K + 1):
            cand = []
            for k in range(m.K):
                mk, _ = _em(d, *_partir(m, k, rng), Qp, mup, lam, a0, n_corto, tol)
                cand.append((mk.objetivo[-1], k, mk))
            obj0, k0, m0 = max(cand, key=lambda t: t[0])
            m, conv = _em(d, m0.pi, m0.mu, m0.P, Qp, mup, lam, a0, max_iter, tol)
            if verbose:
                print(f"    K={nivel}: partiendo el tipo {k0 + 1} -> J={m.objetivo[-1]:.1f} "
                      f"({len(m.objetivo) - 1} iteraciones)", flush=True)
        # Solo el nivel final entra al diagnostico: los niveles previos tienen
        # otra K y no son comparables. La reproducibilidad de la escalera se
        # mide entre SEMILLAS, con `reproducibilidad()`.
        todos = [(m, conv)]
        mejor = m
    elif init == "kmeans":
        F = rasgos(d) if K > 1 else None
        mejor = None
        for i in range(n_init if K > 1 else 1):
            rng = np.random.default_rng([seed, K, i])
            m, conv = _em(d, *_desde_kmeans(d, K, F, rng, Qp, mup, lam, a0),
                          Qp, mup, lam, a0, max_iter, tol)
            todos.append((m, conv))
            if verbose:
                print(f"    K={K} init={i}: J={m.objetivo[-1]:.1f} en {len(m.objetivo) - 1} iteraciones",
                      flush=True)
            if mejor is None or m.objetivo[-1] > mejor.objetivo[-1]:
                mejor = m
    else:
        raise ValueError(f"init desconocido: {init}")

    mejor.diagnostico = estabilidad(mejor, todos, d)
    mejor.diagnostico["init"] = init
    return ordenar_por_largo(mejor)


def _tarjetas(m: Mezcla) -> np.ndarray:
    """(K, 3): pi, E[T] y P(remate) por tipo: lo que se cuenta en el reporte."""
    out = []
    for k in range(m.K):
        c = m.cadena(k)
        B = c.absorcion()
        out.append([m.pi[k], m.mu[k] @ c.largo_esperado(), m.mu[k] @ B[:, :2].sum(1)])
    return np.array(out)


def estabilidad(mejor: Mezcla, todos: list, d: "DatosPosesion", tol_J: float = 50.0) -> dict:
    """¿Es reproducible el óptimo y cambian las tarjetas entre óptimos? (ADR-v2-15)

    Con cientos de miles de secuencias el EM tiene varios óptimos locales;
    exigir que TODOS los arranques coincidan (ADR-v2-12, primera versión) no lo
    cumple ningún K y no es lo relevante. Lo relevante:
      1. reproducibilidad: cuántos arranques llegan a menos de `tol_J` del mejor
         (si solo uno lo encuentra, no sabemos si es el global);
      2. para cada arranque, tras emparejar tipos: acuerdo de asignación y la
         mayor diferencia en las TARJETAS (pi, E[T] relativa, P(remate)). Si las
         tarjetas casi no cambian, la historia es la misma aunque J difiera.
    """
    if mejor.K == 1:
        return {"arranques": [{"J": mejor.objetivo[-1], "convergio": True, "acuerdo": 1.0}],
                "reproducibilidad": 1, "todos_convergieron": True, "acuerdo_minimo": 1.0}
    a_mejor = responsabilidades(mejor, d).argmax(1)
    t_mejor = _tarjetas(mejor)
    J0 = mejor.objetivo[-1]
    filas = []
    for m, conv in todos:
        if m.K != mejor.K:
            continue
        a = responsabilidades(m, d).argmax(1)
        conf = np.zeros((mejor.K, mejor.K))
        np.add.at(conf, (a_mejor, a), 1)
        i, j = linear_sum_assignment(-conf)
        t = _tarjetas(m)[j]
        filas.append({
            "J": float(m.objetivo[-1]), "delta_J": float(J0 - m.objetivo[-1]),
            "iteraciones": len(m.objetivo) - 1, "convergio": bool(conv),
            "acuerdo": float(conf[i, j].sum() / d.n),
            "max_dif_pi": float(np.abs(t[:, 0] - t_mejor[:, 0]).max()),
            "max_dif_ET_rel": float((np.abs(t[:, 1] - t_mejor[:, 1]) / t_mejor[:, 1]).max()),
            "max_dif_Premate": float(np.abs(t[:, 2] - t_mejor[:, 2]).max()),
        })
    cerca = [f for f in filas if f["delta_J"] <= tol_J]
    otros = [f["acuerdo"] for f in filas if f["delta_J"] > 1e-9]
    return {"arranques": filas, "reproducibilidad": len(cerca), "tol_J": tol_J,
            "acuerdo_minimo": float(min(otros)) if otros else 1.0,
            "todos_convergieron": all(f["convergio"] for f in filas)}


def ordenar_por_largo(m: Mezcla) -> Mezcla:
    """Fija el cambio de etiquetas: tipo 1 = el de posesiones mas cortas."""
    et = np.array([m.mu[k] @ m.cadena(k).largo_esperado() for k in range(m.K)])
    o = np.argsort(et)
    return Mezcla(m.pi[o], m.mu[o], m.P[o], m.lam, m.a0, m.objetivo, m.diagnostico)


def reproducibilidad(d: DatosPosesion, K: int, lam: float, a0: float, semillas: list[int],
                     max_iter: int, tol: float, n_corto: int = 25) -> dict:
    """¿La escalera llega al mismo optimo desde semillas distintas? (ADR-v2-17)"""
    Qp, mup = pooled(d)
    ms = [ajustar(d, K, lam, a0, max_iter=max_iter, tol=tol, seed=s, Qp=Qp, mup=mup,
                  init="escalera", n_corto=n_corto) for s in semillas]
    J = np.array([m.objetivo[-1] for m in ms])
    mejor = ms[int(J.argmax())]
    a0_ = responsabilidades(mejor, d).argmax(1)
    filas = []
    for s_, m in zip(semillas, ms):
        a = responsabilidades(m, d).argmax(1)
        conf = np.zeros((K, K))
        np.add.at(conf, (a0_, a), 1)
        i, j = linear_sum_assignment(-conf)
        t, t0 = _tarjetas(m)[j], _tarjetas(mejor)
        filas.append({"semilla": s_, "delta_J": float(J.max() - m.objetivo[-1]),
                      "acuerdo": float(conf[i, j].sum() / d.n),
                      "max_dif_pi": float(np.abs(t[:, 0] - t0[:, 0]).max()),
                      "max_dif_ET_rel": float((np.abs(t[:, 1] - t0[:, 1]) / t0[:, 1]).max())})
    return {"K": K, "semillas": filas,
            "rango_J": float(J.max() - J.min()),
            "acuerdo_minimo": float(min(f["acuerdo"] for f in filas))}


def responsabilidades(m: Mezcla, d: DatosPosesion) -> np.ndarray:
    Lpi = _loglik_tipos(d, m.P, m.mu) + np.log(m.pi)[None]
    return np.exp(Lpi - logsumexp(Lpi, axis=1, keepdims=True))


def loglik_por_posesion(m: Mezcla, d: DatosPosesion) -> np.ndarray:
    return logsumexp(_loglik_tipos(d, m.P, m.mu) + np.log(m.pi)[None], axis=1)


# ======================================================================
# Eleccion de K
# ======================================================================
def cv_k(
    d: DatosPosesion, k_grid: list[int], lam: float, a0: float = 1.0, folds: int = 5,
    seed: int = 0, n_init: int = 2, max_iter: int = 200, tol: float = 1e-6,
    frac_partidos: float = 1.0, verbose: bool = True,
) -> tuple[pl.DataFrame, int]:
    """Log-verosimilitud fuera de muestra (nats/transicion), pliegues POR PARTIDO."""
    partidos = d.meta["match_id"].to_numpy()
    uniq = np.unique(partidos)
    rng = np.random.default_rng(seed)
    if frac_partidos < 1.0:
        uniq = np.sort(rng.choice(uniq, size=max(folds, int(frac_partidos * len(uniq))), replace=False))
    sel = np.isin(partidos, uniq)
    pliegues = match_folds(uniq, folds, seed)
    filas = []
    for K in k_grid:
        for f, test_m in enumerate(pliegues):
            te = sel & np.isin(partidos, test_m)
            tr = sel & ~te
            dtr, dte = d.sub(tr), d.sub(te)
            Qp, mup = pooled(dtr)
            m = ajustar(dtr, K, lam, a0, n_init, max_iter, tol, seed, Qp, mup)
            ll = float(loglik_por_posesion(m, dte).sum())
            nt_ = float(dte.largo.sum())
            filas.append({"K": K, "pliegue": f, "loglik": ll, "transiciones": nt_,
                          "nats_por_transicion": ll / nt_})
            if verbose:
                print(f"  K={K} pliegue={f}: {ll / nt_:.5f} nats/transición", flush=True)
    det = pl.DataFrame(filas)
    return resumen_cv(det, folds), det


def resumen_cv(det: pl.DataFrame, folds: int) -> pl.DataFrame:
    """Resumen por K con errores PAREADOS por pliegue.

    Los pliegues son los mismos para todos los K, asi que la comparacion
    correcta entre K y K-1 es la diferencia pliegue a pliegue. El EE sin
    parear mezcla la dificultad de cada pliegue (un pliegue siempre peor que
    otro) con la diferencia entre modelos y hace parecer "empatados" a K que
    no lo estan: con la primera corrida real la regla 1-EE sin parear dio K=5
    cuando todas las mejoras hasta K=8 tenian t > 9.
    """
    ancho = det.pivot(on="K", index="pliegue", values="nats_por_transicion").sort("pliegue")
    ks = sorted(det["K"].unique().to_list())
    M = np.column_stack([ancho[str(k)].to_numpy() for k in ks])
    score = np.array([
        det.filter(pl.col("K") == k)["loglik"].sum() / det.filter(pl.col("K") == k)["transiciones"].sum()
        for k in ks
    ])
    total = (M[:, -1] - M[:, 0]).mean() if len(ks) > 1 else 1.0
    delta, se, frac = [np.nan], [np.nan], [0.0]
    for j in range(1, len(ks)):
        d = M[:, j] - M[:, j - 1]
        delta.append(d.mean())
        se.append(d.std(ddof=1) / np.sqrt(len(d)))
        frac.append(((M[:, j] - M[:, 0]).mean() / total) if total else np.nan)
    return pl.DataFrame({
        "K": ks, "score": score, "delta_vs_Km1": delta, "se_pareado": se,
        "t": np.array(delta) / np.array(se), "ganancia_acumulada": frac,
    })


# ======================================================================
# Lectura de los tipos
# ======================================================================
def resumen_tipos(m: Mezcla, d: DatosPosesion, r: np.ndarray, n_tipicas: int = 5,
                  t_min: int = 1) -> list[dict]:
    """Por tipo: peso, E[T], desenlaces, xG por posesion (modelo Y empirico),
    visitas por zona y posesiones tipicas. Modelo y empirico deben parecerse:
    si no, el tipo esta mal ajustado y no se nombra."""
    nt, ns = d.n_transient, d.n_states
    n_zonas = nt // d.n_phases
    out = []
    uids = d.meta["seq_uid" if "seq_uid" in d.meta.columns else "poss_uid"].to_numpy()
    arg = r.argmax(axis=1)
    remata = np.asarray(d.S[:, :] @ _es_remate(nt, ns)).ravel() > 0
    xg_pos = np.asarray(d.X.sum(axis=1)).ravel()
    for k in range(m.K):
        cad = m.cadena(k)
        diag = cad.check()
        t = cad.largo_esperado()
        B = cad.absorcion()
        w = r[:, k]
        Ck = np.asarray(d.S.T @ w).reshape(nt, ns)
        xg_k = np.asarray(d.X.T @ w).ravel()
        c = recompensa_xg(Ck.sum(axis=1), xg_k)
        V = cad.valor(c)
        vis = cad.visitas(m.mu[k])
        vis_z = vis.reshape(n_zonas, d.n_phases).sum(axis=1)
        pesos = w / max(w.sum(), _EPS)
        # Comparacion justa con datos truncados en T >= t_min (C3). Solo 1 y 2
        # tienen forma cerrada simple; 2 era el default viejo.
        ET, xG = float(m.mu[k] @ t), float(m.mu[k] @ V)
        if t_min == 2:
            p1 = float(m.mu[k] @ cad.R.sum(axis=1))          # P(T = 1)
            ET_c, xG_c = (ET - p1) / (1 - p1), (xG - float(m.mu[k] @ c)) / (1 - p1)
        elif t_min == 1:
            ET_c, xG_c = ET, xG
        else:
            raise ValueError("resumen_tipos solo sabe condicionar en t_min 1 o 2")
        # posesiones tipicas: asignadas con certeza y de largo cercano a la mediana del tipo
        cand = np.flatnonzero((arg == k) & (w > 0.9))
        tip = []
        if cand.size:
            med = np.median(d.largo[cand])
            cerca = cand[np.abs(d.largo[cand] - med) <= max(1, 0.1 * med)]
            cerca = cerca if cerca.size else cand
            tip = uids[cerca[np.argsort(-w[cerca])][:n_tipicas]].tolist()
        out.append({
            "tipo": k + 1,
            "pi": float(m.pi[k]),
            "rho_Q": diag["rho_Q"],
            "E_T_modelo": ET_c,
            "E_T_modelo_sin_truncar": ET,
            "E_T_empirico": float(pesos @ d.largo),
            "P_gol": float(m.mu[k] @ B[:, 0]),
            "P_remate_sin_gol": float(m.mu[k] @ B[:, 1]),
            "P_perdida": float(m.mu[k] @ B[:, 2]),
            "P_fuera": float(m.mu[k] @ B[:, 3]),
            "P_remate_empirico": float(pesos @ remata),
            "xG_por_posesion_modelo": xG_c,
            "xG_por_posesion_empirico": float(pesos @ xg_pos),
            "visitas_por_zona": vis_z.tolist(),
            "inicio_por_zona": m.mu[k].reshape(n_zonas, d.n_phases).sum(axis=1).tolist(),
            "valor_por_zona": _por_zona(V, c, Ck, n_zonas, d.n_phases),
            "posesiones_tipicas": tip,
        })
    return out


def _es_remate(nt: int, ns: int) -> np.ndarray:
    to = np.arange(nt * ns) % ns
    return ((to == nt) | (to == nt + 1)).astype(float)


def _por_zona(V, c, Ck, n_zonas, n_phases):
    w = Ck.sum(axis=1)
    Vz = (V * w).reshape(n_zonas, n_phases).sum(1) / np.maximum(w.reshape(n_zonas, n_phases).sum(1), _EPS)
    return Vz.tolist()


# ======================================================================
# Bondad de ajuste de la duracion (el criterio que rechazo a K = 1)
# ======================================================================
def supervivencia_mezcla(m: Mezcla, kmax: int) -> np.ndarray:
    """S(t) = sum_k pi_k mu^k' Q_k^t 1: phase-type de la mezcla, SIN simular."""
    return sum(m.pi[k] * m.cadena(k).supervivencia(m.mu[k], kmax) for k in range(m.K))


def _pmf_condicionada(S: np.ndarray, t_min: int) -> np.ndarray:
    pmf = np.clip(-np.diff(S), 0.0, None)          # P(T = t), t = 1..kmax
    pmf[: max(t_min - 1, 0)] = 0.0
    return pmf / max(pmf.sum(), _EPS)


def ks_largo(largos: np.ndarray, S: np.ndarray, t_min: int) -> float:
    kmax = len(S) - 1
    obs = largos[largos >= t_min]
    cnt = np.bincount(np.clip(obs, 1, kmax), minlength=kmax + 1)[1:]
    ecdf = np.cumsum(cnt) / max(cnt.sum(), 1)
    tcdf = np.cumsum(_pmf_condicionada(S, t_min))
    return float(np.abs(ecdf - tcdf).max())


def simular_largos(m: Mezcla, n: int, rng: np.random.Generator, t_min: int,
                   kmax: int = 400) -> np.ndarray:
    """Largos simulados desde la mezcla, truncados igual que los datos."""
    out = []
    nt = m.mu.shape[1]
    faltan = n
    while faltan > 0:
        tipos = rng.choice(m.K, size=int(faltan * 1.6) + 50, p=m.pi)
        for k in range(m.K):
            nk = int((tipos == k).sum())
            if nk == 0:
                continue
            est = rng.choice(nt, size=nk, p=m.mu[k])
            T = np.zeros(nk, dtype=int)
            vivos = np.ones(nk, dtype=bool)
            cum = np.cumsum(m.P[k], axis=1)
            for _ in range(kmax):
                idx = np.flatnonzero(vivos)
                if idx.size == 0:
                    break
                u = rng.random(idx.size)
                nxt = np.minimum((cum[est[idx]] < u[:, None]).sum(axis=1), m.P.shape[2] - 1)
                T[idx] += 1
                ab = nxt >= nt
                vivos[idx[ab]] = False
                est[idx[~ab]] = nxt[~ab]
            out.append(T[T >= t_min])
        tot = np.concatenate(out)
        faltan = n - len(tot)
    return np.concatenate(out)[:n]


def bondad_largo(m: Mezcla, d: DatosPosesion, t_min: int, kmax: int = 60,
                 n_boot: int = 0, seed: int = 0) -> dict:
    """KS entre la duracion empirica y la phase-type de la mezcla.

    El p-valor usa bootstrap parametrico SIN reajustar el modelo en cada
    replica. Sin reajuste la nula del KS es estocasticamente MAYOR que la de
    Lilliefors, asi que este p es CONSERVADOR: si rechaza, el reajustado
    tambien rechazaria. Si no rechaza, falta el reajuste para afirmarlo.
    """
    S = supervivencia_mezcla(m, kmax)
    ks = ks_largo(d.largo, S, t_min)
    obs = d.largo[d.largo >= t_min]
    K_ = min(kmax, int(obs.max()))
    cnt = np.bincount(np.clip(obs, 1, K_), minlength=K_ + 1)[1:]
    S_emp = 1.0 - np.cumsum(cnt) / cnt.sum()
    S_teo = 1.0 - np.cumsum(_pmf_condicionada(S, t_min))[:K_]
    res = {"K": m.K, "KS": ks, "n": int(len(obs)), "t_min": t_min,
           "E_T_empirico": float(obs.mean()),
           "E_T_modelo": float(sum(m.pi[k] * (m.mu[k] @ m.cadena(k).largo_esperado())
                                   for k in range(m.K))),
           "supervivencia": [{"t": t + 1, "empirica": float(S_emp[t]), "modelo": float(S_teo[t])}
                             for t in range(min(K_, 30))]}
    if n_boot:
        rng = np.random.default_rng(seed)
        nulos = np.array([ks_largo(simular_largos(m, len(obs), rng, t_min), S, t_min)
                          for _ in range(n_boot)])
        res["KS_nula_p95"] = float(np.percentile(nulos, 95))
        res["p_conservador"] = float((1 + (nulos >= ks).sum()) / (1 + n_boot))
    return res


def guardar_json(obj, path: Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str))
