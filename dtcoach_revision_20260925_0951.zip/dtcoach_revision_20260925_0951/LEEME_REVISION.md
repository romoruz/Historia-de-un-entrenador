# Paquete de revisión — dtcoach (Hackathon ISAC 2026)

Generado: 2026-09-25 09:52 · commit: 77b720bdb44832377099872858de53b404d0ede4 2026-09-23 16:34:01 -0600 v2: estructura inicial, manifiesto de datos crudos, referencia del proyecto viejo

## Qué contiene
- `src/dtcoach/`: el paquete (vocabulario de la liga, fases 2–3, decisiones, simulador).
- `tests/`: pruebas con datos **sintéticos**; corren sin datos de StatsBomb.
- `scripts/`, `config/`, `docs/` (roadmap, framework, decisiones ADR, hipótesis pre-registradas, resultados, informe comparativo).
- `reports/`: todas las salidas ya calculadas (tablas `.md`, `.json`, `.csv`, figuras `.png`, logs).
- `data/referencia/`: eras de técnicos verificadas contra el API (sin eventos).
- `REVISION/`: salida de pytest al empaquetar, entorno (`pip freeze`) y `MANIFIESTO.sha256`.

## Qué NO contiene (y por qué)
Datos de StatsBomb (licenciados, uso exclusivo del reto) ni credenciales. Excluido:
- entorno/caché: 32 archivos
- historial (usa --con-historial): 64 archivos

## Verificación rápida (sin datos)
```bash
unzip dtcoach_revision_20260925_0951.zip -d dtcoach_revision_20260925_0951 && cd dtcoach_revision_20260925_0951
bash VERIFICAR.sh        # integridad (sha256) + instala + corre las pruebas
```

## Reproducir el análisis completo (con datos y credenciales propias)
```bash
# 1. descargar eventos y partidos de Liga MX a data/raw/statsbomb/{events,matches}
dtcoach aplanar && dtcoach partidos && dtcoach fase0
dtcoach mezcla --K 3 && dtcoach reproducibilidad --K 3 && dtcoach bondad --K 1 3
dtcoach elo
bash scripts/correr_foco.sh "Andre Jardine" 30
bash scripts/correr_foco.sh "Guillermo Almada" 7
```

## Orden de lectura sugerido
1. `docs/INFORME_METODO_Y_COMPARACION.md` — método, resultados y comparación entre proyectos.
2. `docs/11_HIPOTESIS.md` — hipótesis pre-registradas y enmiendas (con fecha).
3. `docs/10_RESULTADOS.md` — resultados con etiqueta de evidencia (🟢🟡⚪🔴).
4. `docs/06_DECISIONES.md` — decisiones de diseño (ADR-v2-01 a 28).
5. `docs/03_FRAMEWORK.md` y `docs/01_ARQUITECTURA.md`.

## Indicación para la IA que revise este paquete
Verifica cada afirmación contra el código y los reportes incluidos antes de aceptarla.
Prioriza: (1) validez de la unidad de análisis y de la inferencia (clusters, FDR,
reproducibilidad de la mezcla), (2) coherencia entre `docs/` y `reports/`,
(3) supuestos declarados en `docs/03_FRAMEWORK.md`. Señala contradicciones con
archivo y línea.
