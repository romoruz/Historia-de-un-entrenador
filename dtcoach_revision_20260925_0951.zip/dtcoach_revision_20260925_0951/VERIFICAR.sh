#!/usr/bin/env bash
# Verifica integridad, instala en un entorno aislado y corre las pruebas (no requiere datos).
set -euo pipefail
cd "$(dirname "$0")"
echo "== integridad (sha256)"
if command -v sha256sum >/dev/null; then sha256sum -c --quiet REVISION/MANIFIESTO.sha256
else shasum -a 256 -c --quiet REVISION/MANIFIESTO.sha256; fi
echo "   OK"
echo "== entorno"
if command -v uv >/dev/null; then
  uv venv --python 3.12 .venv >/dev/null && uv pip install --python .venv/bin/python -e ".[dev]" >/dev/null
else
  python3 -m venv .venv && .venv/bin/pip install -q -e ".[dev]"
fi
echo "== pruebas"
.venv/bin/python -m pytest -q
echo
echo "Código verificado. El análisis completo requiere datos de StatsBomb (ver LEEME_REVISION.md)."
