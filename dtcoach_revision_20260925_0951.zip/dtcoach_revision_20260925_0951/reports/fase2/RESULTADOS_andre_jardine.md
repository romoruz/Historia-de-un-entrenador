# Resultados de la fase 2 — Andre Jardine

Secuencias del foco: 22,562 (ataque), 22,526 (defensa). Partidos: 183 del foco, 1584 de la liga.
Modelo convergió: True. Columnas no estimables: ninguna. 

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=11.2 (gl 2) | 0.0036 | 0.0109 | 🟢 |
| H2 | identidad defensiva | W=30.8 (gl 2) | 0.0000 | 0.0000 | 🟢 |
| H3 | reacción al marcador | W=5.5 (gl 4) | 0.2365 | 0.3153 | ⚪ |
| H4 | final del partido | W=0.1 (gl 2) | 0.9389 | 0.9389 | ⚪ |
| H5 | localía | W=0.7 (gl 2) | 0.7058 | 0.7700 | ⚪ |
| H6 | fuerza del rival | W=2.3 (gl 2) | 0.3106 | 0.3727 | ⚪ |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0018 [-0.0005, +0.0040] | 0.1125 | 0.1687 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=+0.0015 [+0.0007, +0.0023] | 0.0005 | 0.0020 | 🟢 |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=+0.0020 [+0.0009, +0.0032] | 0.0005 | 0.0020 | 🟢 |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0018 [-0.0039, -0.0000] | 0.0625 | 0.1071 | ⚪ |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=-0.0004 [-0.0009, -0.0000] | 0.0575 | 0.1071 | ⚪ |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=-0.0012 [-0.0021, -0.0004] | 0.0055 | 0.0132 | 🟢 |

## En la cancha

- [H1 🟢] Con Andre Jardine, 31.8 % de sus secuencias son «Directa», contra 30.8 % de la liga en las mismas situaciones (+1.0 pp, IC 95 % [+0.2 pp, +1.8 pp]).
- [H1 🟢] Con Andre Jardine, 25.2 % de sus secuencias son «Circulación estéril», contra 25.9 % de la liga en las mismas situaciones (-0.7 pp, IC 95 % [-1.3 pp, -0.2 pp]).
- [H1 🟢] Con Andre Jardine, 43.0 % de sus secuencias son «Ataque elaborado», contra 43.3 % de la liga en las mismas situaciones (-0.2 pp, IC 95 % [-1.2 pp, +0.7 pp]).
- [H2 🟢] Con Andre Jardine, 31.7 % de las secuencias de sus rivales son «Directa», contra 33.8 % de la liga en las mismas situaciones (-2.1 pp, IC 95 % [-2.9 pp, -1.3 pp]).
- [H2 🟢] Con Andre Jardine, 26.6 % de las secuencias de sus rivales son «Circulación estéril», contra 27.1 % de la liga en las mismas situaciones (-0.5 pp, IC 95 % [-1.0 pp, -0.0 pp]).
- [H2 🟢] Con Andre Jardine, 41.7 % de las secuencias de sus rivales son «Ataque elaborado», contra 39.1 % de la liga en las mismas situaciones (+2.7 pp, IC 95 % [+1.6 pp, +3.6 pp]).
- [H7.1 ⚪] eficiencia ofensiva · Directa: no detectamos una diferencia mayor a 0.0040 xG por secuencia.
- [H7.2 🟢] eficiencia ofensiva · Circulación estéril: 0.0048 contra 0.0032 xG por secuencia (dif. +0.0015, IC [+0.0007, +0.0023]).
- [H7.3 🟢] eficiencia ofensiva · Ataque elaborado: 0.0134 contra 0.0113 xG por secuencia (dif. +0.0020, IC [+0.0009, +0.0032]).
- [H8.1 ⚪] eficiencia defensiva · Directa: no detectamos una diferencia mayor a 0.0039 xG por secuencia.
- [H8.2 ⚪] eficiencia defensiva · Circulación estéril: no detectamos una diferencia mayor a 0.0009 xG por secuencia.
- [H8.3 🟢] eficiencia defensiva · Ataque elaborado: 0.0102 contra 0.0113 xG por secuencia (dif. -0.0012, IC [-0.0021, -0.0004]).