# Resultados de la fase 2 — Guillermo Almada

Secuencias del foco: 23,639 (ataque), 23,564 (defensa). Partidos: 166 del foco, 1601 de la liga.
Modelo convergió: True. Columnas no estimables: ninguna. 

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=6.0 (gl 2) | 0.0492 | 0.0984 | 🟡 |
| H2 | identidad defensiva | W=10.2 (gl 2) | 0.0061 | 0.0146 | 🟢 |
| H3 | reacción al marcador | W=16.7 (gl 4) | 0.0022 | 0.0088 | 🟢 |
| H4 | final del partido | W=1.0 (gl 2) | 0.6160 | 0.6720 | ⚪ |
| H5 | localía | W=3.7 (gl 2) | 0.1564 | 0.2345 | ⚪ |
| H6 | fuerza del rival | W=21.2 (gl 2) | 0.0000 | 0.0003 | 🟢 |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0004 [-0.0017, +0.0021] | 0.7485 | 0.7485 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=+0.0004 [-0.0002, +0.0009] | 0.1885 | 0.2513 | ⚪ |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=-0.0002 [-0.0010, +0.0005] | 0.6095 | 0.6720 | ⚪ |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0032 [-0.0049, -0.0016] | 0.0005 | 0.0030 | 🟢 |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=-0.0006 [-0.0012, -0.0000] | 0.0595 | 0.1020 | ⚪ |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=-0.0015 [-0.0024, -0.0006] | 0.0055 | 0.0146 | 🟢 |

## En la cancha

- [H1 🟡] Con Guillermo Almada, 31.7 % de sus secuencias son «Directa», contra 31.3 % de la liga en las mismas situaciones (+0.4 pp, IC 95 % [-0.3 pp, +1.1 pp]).
- [H1 🟡] Con Guillermo Almada, 25.9 % de sus secuencias son «Circulación estéril», contra 26.4 % de la liga en las mismas situaciones (-0.5 pp, IC 95 % [-1.0 pp, -0.1 pp]).
- [H1 🟡] Con Guillermo Almada, 42.4 % de sus secuencias son «Ataque elaborado», contra 42.3 % de la liga en las mismas situaciones (+0.1 pp, IC 95 % [-0.7 pp, +1.0 pp]).
- [H2 🟢] Con Guillermo Almada, 34.3 % de las secuencias de sus rivales son «Directa», contra 33.1 % de la liga en las mismas situaciones (+1.2 pp, IC 95 % [+0.5 pp, +2.0 pp]).
- [H2 🟢] Con Guillermo Almada, 26.9 % de las secuencias de sus rivales son «Circulación estéril», contra 27.3 % de la liga en las mismas situaciones (-0.3 pp, IC 95 % [-0.8 pp, +0.2 pp]).
- [H2 🟢] Con Guillermo Almada, 38.7 % de las secuencias de sus rivales son «Ataque elaborado», contra 39.6 % de la liga en las mismas situaciones (-0.9 pp, IC 95 % [-1.8 pp, -0.0 pp]).
- [contexto] ganando vs empatando: el equipo de Guillermo Almada cambia su uso de «Directa» +3.2 pp; la liga, +5.0 pp (diferencia -1.9 pp, IC [-3.5 pp, -0.3 pp]).
- [contexto] ganando vs empatando: el equipo de Guillermo Almada cambia su uso de «Ataque elaborado» -3.2 pp; la liga, -5.8 pp (diferencia +2.6 pp, IC [+0.9 pp, +4.3 pp]).
- [contexto] rival 100 Elo más fuerte vs igual: el equipo de Guillermo Almada cambia su uso de «Directa» +1.0 pp; la liga, +2.5 pp (diferencia -1.5 pp, IC [-2.3 pp, -0.7 pp]).
- [contexto] rival 100 Elo más fuerte vs igual: el equipo de Guillermo Almada cambia su uso de «Circulación estéril» -0.0 pp; la liga, +0.6 pp (diferencia -0.7 pp, IC [-1.3 pp, -0.1 pp]).
- [contexto] rival 100 Elo más fuerte vs igual: el equipo de Guillermo Almada cambia su uso de «Ataque elaborado» -1.0 pp; la liga, -3.2 pp (diferencia +2.2 pp, IC [+1.3 pp, +3.2 pp]).
- [H7.1 ⚪] eficiencia ofensiva · Directa: no detectamos una diferencia mayor a 0.0021 xG por secuencia.
- [H7.2 ⚪] eficiencia ofensiva · Circulación estéril: no detectamos una diferencia mayor a 0.0009 xG por secuencia.
- [H7.3 ⚪] eficiencia ofensiva · Ataque elaborado: no detectamos una diferencia mayor a 0.0010 xG por secuencia.
- [H8.1 🟢] eficiencia defensiva · Directa: 0.0112 contra 0.0143 xG por secuencia (dif. -0.0032, IC [-0.0049, -0.0016]).
- [H8.2 ⚪] eficiencia defensiva · Circulación estéril: no detectamos una diferencia mayor a 0.0012 xG por secuencia.
- [H8.3 🟢] eficiencia defensiva · Ataque elaborado: 0.0100 contra 0.0115 xG por secuencia (dif. -0.0015, IC [-0.0024, -0.0006]).