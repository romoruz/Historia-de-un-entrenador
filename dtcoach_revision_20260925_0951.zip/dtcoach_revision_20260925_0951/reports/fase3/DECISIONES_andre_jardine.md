# Decisiones desde la banca — Andre Jardine

Equipo-minuto: 136,740 · sustituciones: 14,757 (821 de Andre Jardine) · equipo-partido: 3,351

| id | qué se prueba | resultado | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H13 | tiempo de los cambios | W=12.4 (gl 2) | 0.0020 | 0.0051 | 🟢 |
| H14 | banca contra el marcador | W=1.0 (gl 2) | 0.6045 | 0.6045 | ⚪ |
| H15 | tipo de cambio | W=4.2 (gl 4) | 0.3834 | 0.4792 | ⚪ |
| H16 | reacomodos de formación por partido | 1.721 vs 1.796 (dif -0.075 [-0.223, +0.082]) | 0.3205 | 0.4792 | ⚪ |
| H17 | rotación del once (1 − Jaccard) | 0.398 vs 0.335 (dif +0.063 [+0.028, +0.096]) | 0.0005 | 0.0025 | 🟢 |

## En la cancha

- **Primer cambio del 2º tiempo, empatando:** minuto 60.8 contra 58.0 de la liga (+2.9 min, IC [+1.2, +4.5]).
- **Primer cambio del 2º tiempo, perdiendo:** minuto 57.0 contra 55.0 de la liga (+2.1 min, IC [+0.4, +3.8]).
- **Primer cambio del 2º tiempo, ganando:** minuto 60.4 contra 57.3 de la liga (+3.1 min, IC [+1.2, +4.9]).
- **Tipo de cambio, perdiendo:** defensivo 6 % (liga 8 %, dif -2.8 pp [-5.2, +0.8]); mismo puesto 70 % (liga 69 %, dif +1.3 pp [-5.7, +7.7]); ofensivo 24 % (liga 23 %, dif +1.5 pp [-4.0, +7.1])
- **Tipo de cambio, empatando:** defensivo 12 % (liga 11 %, dif +1.1 pp [-1.2, +3.9]); mismo puesto 76 % (liga 76 %, dif -0.4 pp [-4.7, +3.9]); ofensivo 12 % (liga 13 %, dif -0.8 pp [-3.7, +2.9])
- **Formaciones iniciales en América** (129 partidos, 9 sistemas): 4231 (57, 44 %), 442 (26, 20 %), 343 (14, 11 %), 433 (9, 7 %), 3421 (8, 6 %)
- **Formaciones iniciales en Atlético San Luis** (54 partidos, 10 sistemas): 4231 (23, 43 %), 442 (16, 30 %), 433 (7, 13 %), 4141 (2, 4 %), 451 (1, 2 %)