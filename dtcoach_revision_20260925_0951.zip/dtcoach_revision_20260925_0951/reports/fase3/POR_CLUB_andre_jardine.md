# ¿Es él o el plantel? — Andre Jardine

## América (129 partidos)

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=3.2 (gl 2) | 0.2060 | 0.2747 | ⚪ |
| H2 | identidad defensiva | W=21.9 (gl 2) | 0.0000 | 0.0002 | 🟢 |
| H3 | reacción al marcador | W=9.9 (gl 4) | 0.0423 | 0.0634 | 🟡 |
| H4 | final del partido | W=0.1 (gl 2) | 0.9287 | 0.9287 | ⚪ |
| H5 | localía | W=1.0 (gl 2) | 0.5925 | 0.7109 | ⚪ |
| H6 | fuerza del rival | W=0.6 (gl 2) | 0.7363 | 0.8032 | ⚪ |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0038 [+0.0008, +0.0066] | 0.0055 | 0.0094 | 🟢 |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=+0.0023 [+0.0012, +0.0033] | 0.0005 | 0.0015 | 🟢 |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=+0.0028 [+0.0013, +0.0042] | 0.0005 | 0.0015 | 🟢 |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0036 [-0.0056, -0.0017] | 0.0015 | 0.0036 | 🟢 |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=-0.0007 [-0.0012, -0.0003] | 0.0035 | 0.0070 | 🟢 |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=-0.0020 [-0.0029, -0.0011] | 0.0005 | 0.0015 | 🟢 |

## Atlético San Luis (54 partidos)

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=16.3 (gl 2) | 0.0003 | 0.0035 | 🟢 |
| H2 | identidad defensiva | W=7.8 (gl 2) | 0.0202 | 0.0809 | 🟡 |
| H3 | reacción al marcador | W=6.7 (gl 4) | 0.1512 | 0.4537 | ⚪ |
| H4 | final del partido | W=0.3 (gl 2) | 0.8707 | 0.8875 | ⚪ |
| H5 | localía | W=1.8 (gl 2) | 0.4078 | 0.6991 | ⚪ |
| H6 | fuerza del rival | W=13.8 (gl 2) | 0.0010 | 0.0061 | 🟢 |
| H7.1 | eficiencia ofensiva · Directa | dif=-0.0020 [-0.0055, +0.0009] | 0.2135 | 0.5124 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=-0.0001 [-0.0008, +0.0007] | 0.8485 | 0.8875 | ⚪ |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=-0.0001 [-0.0016, +0.0013] | 0.8875 | 0.8875 | ⚪ |
| H8.1 | eficiencia defensiva · Directa | dif=+0.0022 [-0.0019, +0.0061] | 0.2825 | 0.5650 | ⚪ |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=+0.0002 [-0.0007, +0.0010] | 0.6805 | 0.8875 | ⚪ |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=+0.0003 [-0.0015, +0.0020] | 0.7055 | 0.8875 | ⚪ |

## Veredicto (H9–H12, pre-registradas)

**H9 identidad defensiva**
- Directa: VIAJA (ambos clubes, mismo signo)
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: VIAJA (ambos clubes, mismo signo)

**H10 eficiencia ofensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H11 eficiencia defensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H12 mezcla ofensiva distinta entre clubes**
- Directa: dif -2.2 pp, IC [-3.8, -0.5] → distinta
- Circulación estéril: dif +0.6 pp, IC [-0.5, +1.7] → no detectamos diferencia
- Ataque elaborado: dif +1.6 pp, IC [-0.2, +3.4] → no detectamos diferencia
