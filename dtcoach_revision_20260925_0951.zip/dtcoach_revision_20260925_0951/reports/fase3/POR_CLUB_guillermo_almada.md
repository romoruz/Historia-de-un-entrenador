# ¿Es él o el plantel? — Guillermo Almada

## Pachuca (139 partidos)

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=6.8 (gl 2) | 0.0333 | 0.0643 | 🟡 |
| H2 | identidad defensiva | W=3.2 (gl 2) | 0.1999 | 0.2999 | ⚪ |
| H3 | reacción al marcador | W=11.8 (gl 4) | 0.0188 | 0.0563 | 🟡 |
| H4 | final del partido | W=0.2 (gl 2) | 0.8949 | 0.9055 | ⚪ |
| H5 | localía | W=2.8 (gl 2) | 0.2512 | 0.3350 | ⚪ |
| H6 | fuerza del rival | W=18.3 (gl 2) | 0.0001 | 0.0013 | 🟢 |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0002 [-0.0022, +0.0023] | 0.9055 | 0.9055 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=+0.0006 [-0.0000, +0.0012] | 0.0375 | 0.0643 | 🟡 |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=-0.0001 [-0.0011, +0.0007] | 0.7805 | 0.9055 | ⚪ |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0030 [-0.0050, -0.0013] | 0.0045 | 0.0180 | 🟢 |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=-0.0007 [-0.0013, -0.0002] | 0.0245 | 0.0588 | 🟡 |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=-0.0018 [-0.0029, -0.0009] | 0.0025 | 0.0150 | 🟢 |

## Santos Laguna (20 partidos)

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=10.6 (gl 2) | 0.0051 | 0.0236 | 🟢 |
| H2 | identidad defensiva | W=41.0 (gl 2) | 0.0000 | 0.0000 | 🟢 |
| H3 | reacción al marcador | W=14.5 (gl 4) | 0.0059 | 0.0236 | 🟢 |
| H4 | final del partido | W=2.6 (gl 2) | 0.2718 | 0.4078 | ⚪ |
| H5 | localía | W=2.3 (gl 2) | 0.3209 | 0.4279 | ⚪ |
| H6 | fuerza del rival | W=4.1 (gl 2) | 0.1302 | 0.2603 | ⚪ |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0010 [-0.0033, +0.0048] | 0.6675 | 0.7282 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=-0.0011 [-0.0024, -0.0002] | 0.0685 | 0.1644 | ⚪ |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=-0.0014 [-0.0036, +0.0006] | 0.1965 | 0.3369 | ⚪ |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0041 [-0.0075, -0.0008] | 0.0305 | 0.0915 | 🟡 |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=-0.0001 [-0.0029, +0.0018] | 0.8325 | 0.8325 | ⚪ |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=+0.0008 [-0.0019, +0.0035] | 0.5785 | 0.6942 | ⚪ |

## América (7 partidos)

⚠ solo 7 partidos del foco: la varianza sandwich de sus coeficientes se apoya en muy pocos conglomerados y sus IC tienden a ser demasiado estrechos. Lectura exploratoria, sin 🟢.

| hipótesis | qué se prueba | estadístico | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H1 | identidad ofensiva | W=2.0 (gl 2) | 0.3686 | 0.7372 | ⚪ |
| H2 | identidad defensiva | W=0.4 (gl 2) | 0.8317 | 0.9045 | ⚪ |
| H3 | reacción al marcador | W=5.0 (gl 4) | 0.2879 | 0.7372 | ⚪ |
| H4 | final del partido | W=1.3 (gl 2) | 0.5189 | 0.8895 | ⚪ |
| H5 | localía | W=0.9 (gl 2) | 0.6279 | 0.9045 | ⚪ |
| H6 | fuerza del rival | W=4.5 (gl 2) | 0.1069 | 0.6414 | ⚪ |
| H7.1 | eficiencia ofensiva · Directa | dif=+0.0028 [-0.0024, +0.0077] | 0.3175 | 0.7372 | ⚪ |
| H7.2 | eficiencia ofensiva · Circulación estéril | dif=-0.0000 [-0.0020, +0.0014] | 0.9045 | 0.9045 | ⚪ |
| H7.3 | eficiencia ofensiva · Ataque elaborado | dif=+0.0017 [+0.0003, +0.0030] | 0.0085 | 0.1020 | 🟡 |
| H8.1 | eficiencia defensiva · Directa | dif=-0.0028 [-0.0078, +0.0008] | 0.2275 | 0.7372 | ⚪ |
| H8.2 | eficiencia defensiva · Circulación estéril | dif=+0.0002 [-0.0019, +0.0021] | 0.8405 | 0.9045 | ⚪ |
| H8.3 | eficiencia defensiva · Ataque elaborado | dif=-0.0001 [-0.0053, +0.0041] | 0.8795 | 0.9045 | ⚪ |

## Veredicto Pachuca vs Santos Laguna (H9–H12, pre-registradas)

⚠ Santos Laguna tiene 20 partidos: poca potencia. Un «no se detecta en ambos» aquí NO significa «no viaja»; y sus IC son poco fiables (sandwich con pocos partidos).

**H9 identidad defensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H10 eficiencia ofensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H11 eficiencia defensiva**
- Directa: VIAJA (ambos clubes, mismo signo)
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H12 mezcla ofensiva distinta entre clubes**
- Directa: dif +1.9 pp, IC [+0.1, +3.7] → distinta
- Circulación estéril: dif +0.7 pp, IC [-0.3, +1.8] → no detectamos diferencia
- Ataque elaborado: dif -2.6 pp, IC [-4.5, -0.7] → distinta

## Veredicto Pachuca vs América (H9–H12, pre-registradas)

⚠ América tiene 7 partidos: poca potencia. Un «no se detecta en ambos» aquí NO significa «no viaja»; y sus IC son poco fiables (sandwich con pocos partidos).

**H9 identidad defensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H10 eficiencia ofensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H11 eficiencia defensiva**
- Directa: no se detecta en ambos
- Circulación estéril: no se detecta en ambos
- Ataque elaborado: no se detecta en ambos

**H12 mezcla ofensiva distinta entre clubes**
- Directa: dif +2.4 pp, IC [-0.1, +4.9] → no detectamos diferencia
- Circulación estéril: dif -0.6 pp, IC [-2.7, +1.6] → no detectamos diferencia
- Ataque elaborado: dif -1.8 pp, IC [-5.3, +1.7] → no detectamos diferencia
