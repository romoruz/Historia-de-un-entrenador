# Decisiones desde la banca — Guillermo Almada

Equipo-minuto: 137,387 · sustituciones: 14,822 (726 de Guillermo Almada) · equipo-partido: 3,368

| id | qué se prueba | resultado | p | q (BH) | evidencia |
|---|---|---|---|---|---|
| H13 | tiempo de los cambios | W=5.1 (gl 2) | 0.0763 | 0.1059 | ⚪ |
| H14 | banca contra el marcador | W=4.9 (gl 2) | 0.0847 | 0.1059 | ⚪ |
| H15 | tipo de cambio | W=44.6 (gl 4) | 0.0000 | 0.0000 | 🟢 |
| H16 | reacomodos de formación por partido | 1.404 vs 1.810 (dif -0.407 [-0.574, -0.237]) | 0.0005 | 0.0012 | 🟢 |
| H17 | rotación del once (1 − Jaccard) | 0.358 vs 0.339 (dif +0.019 [-0.019, +0.060]) | 0.3435 | 0.3435 | ⚪ |

## En la cancha

- **Primer cambio del 2º tiempo, empatando:** minuto 56.9 contra 58.6 de la liga (-1.7 min, IC [-3.4, -0.1]).
- **Primer cambio del 2º tiempo, perdiendo:** minuto 53.3 contra 55.5 de la liga (-2.2 min, IC [-3.5, -0.8]).
- **Primer cambio del 2º tiempo, ganando:** minuto 57.4 contra 58.0 de la liga (-0.5 min, IC [-2.0, +1.0]).
- **Tipo de cambio, perdiendo:** defensivo 7 % (liga 7 %, dif -0.4 pp [-3.5, +4.0]); mismo puesto 82 % (liga 72 %, dif +9.4 pp [+2.1, +14.8]); ofensivo 11 % (liga 20 %, dif -9.0 pp [-12.9, -3.9])
- **Tipo de cambio, empatando:** defensivo 5 % (liga 10 %, dif -5.2 pp [-6.9, -3.2]); mismo puesto 90 % (liga 79 %, dif +11.4 pp [+7.8, +14.0]); ofensivo 5 % (liga 11 %, dif -6.2 pp [-8.2, -3.2])
- **Formaciones iniciales en América** (7 partidos, 1 sistemas): 4231 (7, 100 %)
- **Formaciones iniciales en Pachuca** (139 partidos, 7 sistemas): 4231 (92, 66 %), 442 (31, 22 %), 4411 (8, 6 %), 433 (3, 2 %), 4141 (3, 2 %)
- **Formaciones iniciales en Santos Laguna** (20 partidos, 5 sistemas): 4231 (12, 60 %), 442 (3, 15 %), 433 (3, 15 %), 352 (1, 5 %), 41212 (1, 5 %)