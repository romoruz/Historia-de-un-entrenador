# Inventario de datos StatsBomb — 2026-09-23

Raíz: `data/raw/statsbomb` · partidos procesados: **220** · filtro equipo = `América`

Archivos por clase: events=1767, lineups=1767, matches=6

Eventos: **0** · campos distintos (rutas aplanadas): **0**


**⚠ 440 archivos no se pudieron leer** (ver `calidad.csv`).


## Partidos por torneo (orden cronológico)

| torneo | partidos procesados | con 360 |
|---|---|---|

## Etapas de competición (para decidir liguilla sí/no)

- A2021 · Apertura: 153
- A2021 · Apertura - Finals: 1
- A2021 · Apertura - Quarter-finals: 8
- A2021 · Apertura - Reclasificación: 4
- A2021 · Apertura - Semi-finals: 5
- C2022 · Clausura: 153
- C2022 · Clausura - Final: 2
- C2022 · Clausura - Reclasificacion: 4
- C2022 · Quarter-finals: 8
- C2022 · Semi-finals: 4
- A2022 · Apertura - Final: 2
- A2022 · Apertura - Reclasificación: 4
- A2022 · Quarter-finals: 8
- A2022 · Regular Season: 153
- A2022 · Semi-finals: 4
- C2023 · Clausura: 153
- C2023 · Clausura - Final: 2
- C2023 · Clausura - Quarter-finals: 8
- C2023 · Clausura - Reclasificacion: 4
- C2023 · Clausura - Semi-finals: 4
- A2023 · Apertura: 153
- A2023 · Apertura - Final: 2
- A2023 · Apertura - Quarter-finals: 8
- A2023 · Apertura - Reclasificación: 2
- A2023 · Final: 1
- A2023 · Semi-finals: 4
- C2024 · Clausura: 153
- C2024 · Clausura - Finals: 2
- C2024 · Clausura - Quarter-finals: 8
- C2024 · Clausura - Reclasificacion: 3
- C2024 · Clausura - Semi-finals: 4
- A2024 · Apertura: 153
- A2024 · Apertura - Quarter-finals: 8
- A2024 · Apertura - Semi-finals: 4
- A2024 · Finals: 2
- A2024 · Play-Offs - Finals: 1
- A2024 · Play-offs - Semi-Finals: 2
- C2025 · Clausura: 153
- C2025 · Clausura - Final: 2
- C2025 · Clausura - Semi-finals: 4
- C2025 · Play-In Round: 3
- C2025 · Quarter-finals: 8
- A2025 · Apertura: 153
- A2025 · Apertura - Final: 2
- A2025 · Apertura - Play-in Round: 3
- A2025 · Apertura - Quarter-finals: 8
- A2025 · Apertura - Semi-finals: 4
- C2026 · Clausura: 153
- C2026 · Clausura - Final: 2
- C2026 · Clausura - Quarter-finals: 8
- C2026 · Clausura - Semi-finals: 4
- A2026 · Apertura: 153

## Versiones de datos del proveedor (metadata)

| torneo | data_version | xy_fidelity | shot_fidelity | partidos |
|---|---|---|---|---|
| A2021 | 1.1.0 | 2 | 2 | 171 |
| C2022 | 1.1.0 | 2 | 2 | 171 |
| A2022 | 1.1.0 | 2 | 2 | 171 |
| C2023 | 1.1.0 | 2 | 2 | 171 |
| A2023 | 1.1.0 | 2 | 2 | 170 |
| C2024 | 1.1.0 | 2 | 2 | 170 |
| A2024 | 1.1.0 | 2 | 2 | 170 |
| C2025 | 1.1.0 | 2 | 2 | 170 |
| A2025 | 1.1.0 | 2 | 2 | 170 |
| C2026 | 1.1.0 | 2 | 2 | 167 |
| A2026 | None | None | None | 87 |
| A2026 | 1.1.0 | 2 | 2 | 66 |

## Tipos de evento

| tipo | total | por partido |
|---|---|---|

## Campos cuya presencia cambia ≥ 5% entre torneos (posible deriva del proveedor)

Ninguno (o un solo torneo en la muestra).

## Campos con valores categóricos (lo que puedes filtrar o cruzar)


## Controles de calidad

- periodos: 
- minuto máximo por periodo: 

## Entrenadores (partidos con 0 o >1 managers)

21 combinaciones equipo·torneo con manager vacío o múltiple (ver `entrenadores_por_equipo_torneo.csv`).

## Sección del equipo: América

Entrenadores según `managers` de matches (todos los partidos en metadatos, no solo los procesados):

| torneo | entrenador[id] | partidos |
|---|---|---|
| A2021 | Santiago Hernán Solari Poggio[25] | 19 |
| C2022 | Fernando Ortiz[1001173] | 13 |
| C2022 | Santiago Hernán Solari Poggio[25] | 8 |
| A2022 | Fernando Ortiz[1001173] | 21 |
| C2023 | Fernando Ortiz[1001173] | 21 |
| A2023 | André Soares Jardine[1000116] | 23 |
| C2024 | André Soares Jardine[1000116] | 23 |
| A2024 | André Soares Jardine[1000116] | 24 |
| C2025 | André Soares Jardine[1000116] | 21 |
| C2025 | Diego Alberto Cervantes Chávez[1006259] | 2 |
| A2025 | André Soares Jardine[1000116] | 19 |
| C2026 | André Soares Jardine[1000116] | 19 |
| A2026 | SIN_MANAGER | 10 |
| A2026 | Jorge Guillermo Almada Álves[2947] | 7 |

Formaciones de salida (Starting XI):

## Archivos generados

- `alineaciones.csv`
- `calidad.csv`
- `catalogo_campos.csv`
- `cobertura_360_por_torneo.csv`
- `entrenadores_por_equipo_torneo.csv`
- `eventos_por_partido_por_torneo.csv`
- `formaciones.csv`
- `media_numerica_por_torneo.csv`
- `partidos.csv`
- `presencia_campo_por_torneo.csv`

Tiempo: 6s
