# 11 — Hipótesis (pre-registradas)

> Escrito **antes** de correr `dtcoach fase2` con datos reales (2026-09-24).
> Cambiar una hipótesis, su prueba o su regla de decisión **después** de ver los
> resultados invalida su etiqueta 🟢: pasa a ser exploratoria y se reporta así.

## El objeto

Toda hipótesis se formula en el **vocabulario de la fase 1**: tres familias de
secuencia de la Liga MX (ADR-v2-19).

| # | familia | % liga | acciones | P(remate) | xG/sec |
|---|---|---|---|---|---|
| 1 | **Directa** | 32 % | 3.3 | 0.111 | 0.014 |
| 2 | **Circulación estéril** | 27 % | 6.6 | 0.031 | 0.003 |
| 3 | **Ataque elaborado** | 41 % | 9.0 | 0.144 | 0.011 |

Técnico foco: **André Jardine** (América 129 partidos, San Luis 54).
Referencia: la **liga sin el foco**, es decir, las secuencias de los partidos
donde su equipo no jugó (ADR-v2-22).

## El modelo

Logit multinomial **fraccional** (Papke y Wooldridge, 1996) de las
responsabilidades rₛₖ sobre el contexto, en toda la liga:

- contexto: marcador (perdiendo / empatando / ganando), tramo de minuto
  (0-29, 30-44, 45-59, 60-74, 75+), localía, Elo propio − rival, origen de
  la secuencia (juego abierto, transición, reinicio, balón parado) y
  temporada (efecto fijo, controla la deriva del proveedor);
- **f** = la secuencia es del equipo del foco (ataque), con interacciones
  f × {perdiendo, ganando, minuto 75+, local, Elo};
- **g** = la secuencia es de un rival **contra** el foco (defensa), con g × local.

Varianza **sandwich agrupada por partido**. Efectos traducidos a probabilidad y
promediados sobre las propias secuencias del foco ("contra la liga **en sus
mismas situaciones**"); intervalos por simulación de los coeficientes.

## Las hipótesis

Todas son **bilaterales**: no afirmamos una dirección antes de ver los datos.
Se controla la tasa de falsos descubrimientos con **Benjamini-Hochberg** sobre
las 12 pruebas juntas, con α = 0.05.

| id | pregunta del reto | H₀ (lo que se intenta rechazar) | prueba |
|---|---|---|---|
| **H1** | ¿tiene identidad ofensiva? | en sus mismas situaciones, su equipo usa las 3 familias en la misma proporción que la liga | Wald sobre Δπ promedio, gl = 2 |
| **H2** | ¿tiene identidad defensiva? | sus rivales logran las 3 familias en la misma proporción que contra el resto de la liga | Wald sobre Δπ promedio, gl = 2 |
| **H3** | ¿reacciona al marcador distinto que la liga? | f × perdiendo = f × ganando = 0 | Wald, gl = 4 |
| **H4** | ¿cambia distinto al final del partido? | f × minuto 75+ = 0 | Wald, gl = 2 |
| **H5** | ¿juega distinto de local que de visitante, más que la liga? | f × local = 0 | Wald, gl = 2 |
| **H6** | ¿se adapta a la fuerza del rival más que la liga? | f × Elo = 0 | Wald, gl = 2 |
| **H7.k** | ¿ejecuta mejor la misma familia? (3 pruebas) | xG por secuencia dentro de la familia k = el de la liga | bootstrap por partido |
| **H8.k** | ¿concede menos dentro de la misma familia? (3 pruebas) | xG concedido por secuencia dentro de k = el de la liga | bootstrap por partido |

H1 y H2 dicen **qué** juega. H3 a H6 dicen **cuándo cambia**. H7 y H8 dicen
**qué tan bien** lo hace. La separación es deliberada: un equipo puede generar
más peligro porque elige jugadas más peligrosas (H1) o porque ejecuta mejor las
mismas jugadas (H7). Son dos historias distintas sobre un entrenador.

## Reglas de decisión y de lenguaje

| resultado | etiqueta | cómo se dice |
|---|---|---|
| q < 0.05 | 🟢 probado | "El equipo de Jardine usa X pp más *Ataque elaborado* que la liga en sus mismas situaciones (IC …)." |
| p < 0.05 pero q ≥ 0.05 | 🟡 medido | "Hay indicios de …, que no sobreviven a la corrección por comparaciones múltiples." |
| p ≥ 0.05 | ⚪ no detectado | "No detectamos una diferencia mayor a Y pp", con Y = la cota del IC. **Nunca** "no hay efecto". |

## Qué significa cada combinación (escrito antes de ver datos)

- **H1 🟢 y H3–H6 ⚪** → *identidad por encima de reactividad*: tiene una idea
  de juego propia y no la negocia con el marcador, el minuto ni el rival.
- **H1 ⚪ y H3–H6 algún 🟢** → *técnico reactivo*: su equipo se parece a la
  liga en promedio, pero cambia distinto según la situación.
- **H1 🟢 y H7 ⚪** → la diferencia está en **qué** elige, no en qué tan bien lo
  ejecuta.
- **H1 ⚪ y H7 🟢** → juega lo mismo que todos, **pero mejor**. El mérito
  estaría más en la ejecución, que también puede ser mérito del plantel.
- **Todo ⚪** → con este vocabulario, su equipo no se distingue de la liga.
  Se reporta con las cotas: es un resultado, no un fracaso.

## Lo que estas pruebas NO dicen

- **Nada causal.** "El equipo de Jardine" incluye su plantel, su club y su
  calendario. Separar al técnico del plantel es la fase 3 (Jardine en dos
  clubes).
- Las responsabilidades se tratan como fijas; no se propaga la incertidumbre
  de la mezcla (declarado en `pesos.py`).
- El contexto es el de **la secuencia** (marcador y minuto al inicio de la
  secuencia), no el del partido completo.

## Exploratorio (no entra a la FDR ni lleva 🟢)

Cualquier corte adicional que se haga después de ver los resultados: por
temporada, solo liguilla, solo América sin San Luis, otros técnicos. Se reporta
como ⚪ descriptivo con su IC.

---

# Fase 3 — ¿Es él o es el plantel? (pre-registrado el 2026-09-24, DESPUÉS de ver H1–H8 y ANTES de separar por club)

Resultados de la fase 2 que motivan estas pruebas: H2 🟢 (sus rivales juegan
menos *Directa* y más *Ataque elaborado*), H7.2 y H7.3 🟢 (su equipo genera más
xG dentro de las mismas familias), H8.3 🟢 (concede menos xG en el *Ataque
elaborado* rival). La amenaza: el América tiene un plantel caro, y "ejecutar
mejor" puede ser mérito de los jugadores.

Diseño: el mismo modelo de la fase 2, ajustado **por separado** para Jardine en
el América (129 partidos) y en San Luis (54), cada uno contra la misma liga
(partidos sin Jardine en ningún club). Los partidos de la otra etapa se
excluyen de la referencia.

| id | pregunta | se considera que "viaja" si… |
|---|---|---|
| **H9** | ¿viaja la identidad defensiva (H2)? | en **ambos** clubes el IC de Δπ excluye 0 **con el mismo signo** en *Directa* o en *Ataque elaborado* |
| **H10** | ¿viaja la eficiencia ofensiva (H7.2, H7.3)? | en **ambos** clubes el IC excluye 0 con el mismo signo |
| **H11** | ¿viaja la eficiencia defensiva (H8.3)? | ídem |
| **H12** | ¿su mezcla ofensiva cambia entre clubes? | la diferencia América − San Luis en Δπ ofensivo tiene IC que excluye 0 (aproximación: estimaciones independientes, referencia compartida) |

**Cómo se lee:** "viaja" apunta al técnico, porque el rasgo aparece con dos
planteles distintos. "Solo en el América" es compatible con el plantel. Con 54
partidos, San Luis tiene poca potencia, así que un ⚪ en San Luis se reporta
con su cota ("no detectamos más de X") y **no** como "no viaja".

## Atlas de técnicos (exploratorio, sin FDR ni 🟢)

El mismo modelo para cada era (técnico × club) con al menos 50 partidos. Sirve
para una sola cosa: poner en escala los efectos de Jardine ("¿1 pp es mucho?").
No se usa para afirmar nada de otros técnicos.

---

# Fase 3b — Sus decisiones (pre-registrado el 2026-09-24, antes de programar y de correr)

Hasta aquí medimos lo que hace **el equipo**. Esta fase mide lo que decide **el
técnico** desde la banca: cuándo cambia, qué tipo de cambio hace, cuándo
reacomoda la formación y cuánto rota. Es la parte del reto 5.3 ("uso de
jugadores, cambios en alineaciones, impacto de sustituciones").

Unidad: **equipo-partido** (y equipo-minuto para el tiempo de los cambios),
contra la liga sin el foco. Mismo control de contexto que la fase 2: marcador,
minuto, localía, Elo propio − rival y temporada. Varianza sandwich por partido.

| id | pregunta | H₀ | prueba |
|---|---|---|---|
| **H13** | ¿cambia antes o después que la liga? | el riesgo por minuto de abrir una ventana de cambios es el de la liga (f = 0 y f × tramo = 0) | logit en tiempo discreto por equipo-minuto (min. 45–90), Wald sobre f y f × tiempo, gl = 2 · *enmendada, ver abajo* |
| **H14** | ¿su banca reacciona al marcador distinto que la liga? | f × perdiendo = f × ganando = 0 en ese mismo modelo | Wald gl = 2 |
| **H15** | ¿qué tipo de cambio hace (ofensivo / mismo puesto / defensivo)? | f = f × perdiendo = 0 en un logit multinomial por sustitución | Wald gl = 4 |
| **H16** | ¿reacomoda la formación más o menos que la liga? | `Tactical Shift` por partido igual que la liga | bootstrap por partido |
| **H17** | ¿rota más o menos su once titular? | Jaccard entre onces consecutivos igual que la liga | bootstrap por partido |

Benjamini-Hochberg sobre H13–H17 (familia propia, α = 0.05). Mismas reglas de
lenguaje: 🟢 q < 0.05 · 🟡 p < 0.05 sin FDR · ⚪ "no detectamos más de X".

Definiciones declaradas antes de ver datos:
- **Ventana de cambio**: minuto en el que el equipo hace al menos una sustitución
  (varias en el mismo minuto son **una** decisión). Solo segundo tiempo; los
  cambios del primer tiempo cuentan como ventanas ya usadas (suelen ser lesiones).
- **Tipo de cambio**: nivel del puesto (portero 0, defensa 1, contención 2,
  medio 3, mediapunta y extremo 4, delantero 5). Ofensivo si el que entra juega
  ≥ 1 nivel más adelante que el que sale; defensivo si ≥ 1 más atrás; si no,
  mismo puesto. El puesto del que entra es el de su primer evento.
- **Rotación**: 1 − Jaccard entre los once titulares de partidos consecutivos del
  mismo técnico en el mismo club. No controla días de descanso (limitación).

## Exploratorio (sin FDR)

- **Puntos contra puntos esperados (xPts)**: con el xG de cada remate, los
  goles de cada equipo son Poisson-binomiales (exacto, sin simular). ¿Sacó sus
  equipos más o menos puntos que los que su xG y el de sus rivales predecían?
  Mide suerte y definición, no estilo. Validación previa: en toda la liga, la
  suma de xPts debe coincidir con la de puntos reales.
- **Escenarios**: el modelo de la fase 2 hacia adelante. "¿Qué mezcla de
  familias y cuánto xG por secuencia produce su equipo si va perdiendo al 75' de
  visitante contra un rival más fuerte?", contra la liga en el mismo escenario.
  Supuesto declarado: la eficiencia dentro de cada familia no depende del
  contexto.

**Enmienda a H13 (2026-09-24, antes de correr con datos reales).** Validando
con datos sintéticos se probaron tres versiones de la desviación del foco:

| versión | sin efecto sembrado | adelanto sembrado de 12 min |
|---|---|---|
| f proporcional (original, gl = 1) | — | estimaba 3 min: **aplana** el desplazamiento |
| escalones de 5 min (gl = 9) | rechazaba con p ≈ 1e-35 (**separación**) | −11.4 min |
| escalones gruesos (gl = 3) | 3 de 12 rechazos con p = 0 (separación en el tramo de referencia) | −11.1 min |
| **nivel + pendiente en el tiempo (gl = 2)** | **0 de 20 rechazos** | **−11.9 [−13.2, −10.8]**; con −5 sembrado, −4.6 [−6.2, −3.4] |

Versión final: la liga conserva tramos de 5 minutos y el foco se desvía con un
nivel f y una pendiente f × tiempo. La pregunta es la misma; cambia la prueba, y
todo se decidió sin haber visto datos reales (ADR-v2-25).

---

# Réplica: Guillermo Almada (pre-registrado el 2026-09-24, ANTES de correr)

**Mismas hipótesis H1–H17, mismas pruebas, mismas reglas de decisión y de
lenguaje**, aplicadas a Guillermo Almada con `scripts/correr_foco.sh`. No se
ajusta nada a partir de lo que salió con Jardine.

Etapas: Pachuca (~139 partidos, la principal), Santos (~17–20) y América (8,
temporada 2026/27 en curso). La fase 3a compara Pachuca contra cada una de las
otras dos (H9–H12 por par).

**Reglas específicas por el tamaño de muestra, fijadas antes de ver datos:**
- Un club con menos de 20 partidos del foco **no recibe 🟢** en ninguna prueba:
  la varianza sandwich se apoya en muy pocos conglomerados y sus IC tienden a
  quedar demasiado estrechos. Máximo 🟡, y se lee como exploratorio.
- Con menos de 30 partidos, un "no se detecta en ambos" (H9–H11) **no** se
  reporta como "no viaja", sino como "sin potencia para saberlo".
- El América con Almada (8 partidos) es un **primer vistazo**, no una conclusión.

**Lo que ya vimos antes de pre-registrar (se declara):** el atlas de la fase 3a
incluyó a Almada en Pachuca con 0.7 pp de separación ofensiva (p = 0.034) y
0.7 pp de separación defensiva (p = 0.17). Esos números salen de un ajuste sin
BH y con menos simulaciones; la fase 2 de Almada los recalcula con el diseño
completo.
